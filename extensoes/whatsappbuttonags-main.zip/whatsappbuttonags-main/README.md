# WhatsappbuttonAgs

WhatsAppags is a joomla plugin that adds a customizable WhatsApp message button to the webpage. Clicking on the floating WhatsApp button will display a chat popup that enables your users to send a pre-filled message to a specific WhatsApp user.
 
![](https://github.com/alvinalvin/holamundo/blob/9843350a6d5d97cb643a340ce5365962520f25e2/whasaap.jpg)
### Compatibility
 The module is compatible with Joomla 3 and 4.
### Installation and use

<ul>
<li>Install Joomla! plugin using the extensions manager.</li>
</ul>

![](https://github.com/alvinalvin/holamundo/blob/4d66fb03376df76ea5f4c30825d7b59a66f186e5/imgg.jpg)

<ul>
<li>Look for the extensions manager and go to the plugin.</li>
</ul>

![](https://github.com/alvinalvin/holamundo/blob/ff8684dfcaece9276afdeddf8e408abdd9786cd0/complemen.jpg)

<ul>
<li>configure the plugin.</li>
</ul>

![](https://github.com/alvinalvin/holamundo/blob/90eee897b191705bb058fa5b983916bfb2c96b03/config.jpg)
# Change Log

## Version [1.0.0] - 2023-11-20

<ul>
<li>Adding plugin for Joomla in its first version</li>
</ul>

# Donate
<a title="" href="https://www.paypal.com/donate/?hosted_button_id=B7YYDKUTNU8PS"><img src="https://github.com/alvinalvin/holamundo/blob/1dce12abea45d82ecbce3423f7ecdeb3e5f275a5/PayPal-Donate-Button-PNG.png" alt="" /></a>
### License and Copyright

This module is a open software and has the GNU LESSER GENERAL PUBLIC license. Copyright (C) 2023 Alvin Gil Saldaña All rights reserved.
