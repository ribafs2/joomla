DROP TABLE IF EXISTS `#__securitycheck`;
DROP TABLE IF EXISTS `#__securitycheck_db`;
DROP TABLE IF EXISTS `#__securitycheck_logs`;
DROP TABLE IF EXISTS `#__securitycheck_file_permissions`;
DROP TABLE IF EXISTS `#__securitycheck_file_manager`;
DROP TABLE IF EXISTS `#__securitycheck_storage`;
DROP TABLE IF EXISTS `#__securitycheckpro_update_database`;