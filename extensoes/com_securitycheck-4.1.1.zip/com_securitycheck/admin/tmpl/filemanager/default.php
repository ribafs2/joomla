﻿<?php 
/**
 * @Securitycheck component
 * @copyright Copyright (c) 2011 - Jose A. Luque / Securitycheck Extensions
 * @license   GNU General Public License version 3, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;

Session::checkToken( 'get' ) or die( 'Invalid Token' );

$kind_array = array(HTMLHelper::_('select.option','File', Text::_('COM_SECURITYCHECK_FILEMANAGER_TITLE_FILE')),
			HTMLHelper::_('select.option','Folder', Text::_('COM_SECURITYCHECK_FILEMANAGER_TITLE_FOLDER')));

// Add style declaration
$media_url = "media/com_securitycheck/stylesheets/cpanelui.css";
HTMLHelper::stylesheet($media_url);

// Add style declaration
$media_url = "media/com_securitycheck/stylesheets/font-awesome.min.css";
HTMLHelper::stylesheet($media_url);

echo '<script src="' . JURI::root() . 'media/vendor/jquery/js/jquery.min.js"></script>';	
?>

<script type="text/javascript" language="javascript">
	function get_percent() {
		url = 'index.php?option=com_securitycheck&controller=filemanager&format=raw&task=get_percent';
		jQuery.ajax({
			url: url,							
			method: 'GET',
			success: function(responseText){					
				if ( responseText < 100 ) {
					document.getElementById('current_task').innerHTML = in_progress_string;
					document.getElementById('warning_message').innerHTML = '';
					document.getElementById('error_message').className = 'alert alert-info';
					document.getElementById('error_message').innerHTML = '<?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_ACTIVE_TASK' ); ?>';					
					hideElement('buttonwrapper');
					cont = 3;					
					runButton();
				}					
			}
		});		
	}
	
	function estado_timediff() {
		url = 'index.php?option=com_securitycheck&controller=filemanager&format=raw&task=getEstado_Timediff';
		jQuery.ajax({
			url: url,							
			method: 'GET',
			dataType: 'json',
			success: function(response){				
				var json = Object.keys(response).map(function(k) {return response[k] });
				var estado = json[0];
				var timediff = json[1];
											
				if ( ((estado != 'ENDED') && (estado != error_string)) && (timediff < 3) ) {
					get_percent();
				} else if ( ((estado != 'ENDED') && (estado != error_string)) && (timediff > 3) ) {					
					hideElement('buttonwrapper');
					document.getElementById('current_task').innerHTML = '<?php echo ('<font color="red">Error</font>');?>';
					document.getElementById('warning_message').innerHTML = '';
					document.getElementById('error_message').className = 'alert alert-error';
					document.getElementById('error_message').innerHTML = '<?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_TASK_FAILURE' ); ?>';			
				}						
			},
			error: function(xhr, status) {				
			}
		});		
	}

	jQuery(document).ready(function() {	
		hideElement(backup-progress);
		estado_timediff();
	});
</script>
	
<script type="text/javascript" language="javascript">
	var cont = 0;
	var etiqueta = '';
	var url = '';
	var percent = 0;
	var ended_string = '<?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_ENDED'); ?>';
	var in_progress_string = '<?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_IN_PROGRESS' ); ?>';
	var error_string = '<?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_ERROR' ); ?>';
	var now = '';
		
	function date_time(id) {
		date = new Date();
		year = date.getFullYear();
		month = date.getMonth()+1;
		if (month<10) {
			month = "0"+month;
		}
		day = date.getDate();
		if (day<10) {
			day = "0"+day;
		}
		h = date.getHours();
		if (h<10) {
			h = "0"+h;
		}
		m = date.getMinutes();
		if (m<10) {
			m = "0"+m;
		}
		s = date.getSeconds();
		if (s<10) {
			s = "0"+s;
		}
		now = year+'-'+month+'-'+day+' '+h+':'+m+':'+s
		document.getElementById(id).innerHTML = now;
	}
		
	function runButton() {
						if ( cont == 0 ){							
							document.getElementById('warning_message').innerHTML = '';
							document.getElementById('backup-progress').className="progress";
							date_time('start_time');		
							percent = 0;
						} else if ( cont == 1 ){
							document.getElementById('current_task').innerHTML = in_progress_string;
							url = 'index.php?option=com_securitycheck&controller=filemanager&format=raw&task=acciones';
							jQuery.ajax({
								url: url,							
								method: 'GET',
								success: function(responseText){													
							}
							});								 
						} else {
							url = 'index.php?option=com_securitycheck&controller=filemanager&format=raw&task=get_percent';
							jQuery.ajax({
								url: url,							
								method: 'GET',
								success: function(responseText){
									percent = responseText;																		
									document.getElementById('bar').style.width = percent + "%";
									if (percent == 100) {						
										date_time('end_time');
										hideElement('error_message');										
										document.getElementById('current_task').innerHTML = ended_string;
										document.getElementById('bar').style.width = 100 + "%";										
										document.getElementById('completed_message').innerHTML = '<?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_PROCESS_COMPLETED' ); ?>';
										document.getElementById('warning_message').innerHTML = "<?php echo Text::_( 'COM_SECURITYCHECKPRO_UPDATING_STATS' ); ?> <br/><img src=\"/media/com_securitycheck/images/loading.gif\" width=\"30\" height=\"30\" />";												
										var url_to_redirect = '<?php echo JRoute::_('index.php?option=com_securitycheck&view=filemanager&'. Session::getFormToken() .'=1',false);?>';
										window.location.href = url_to_redirect;
									}
								},
								error: function(responseText) {									
									document.getElementById('warning_message').innerHTML = '';
									document.getElementById('current_task').innerHTML = '<?php echo ('<font color="red">Error</font>');?>';
									document.getElementById('error_message').className = 'alert alert-error';
									document.getElementById('error_message').innerHTML = '<?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_FAILURE' ); ?>';
									document.getElementById('error_button').innerHTML = '<?php echo ('<button class="btn btn-primary" type="button" onclick="window.location.reload();">' . Text::_( 'COM_SECURITYCHECK_FILEMANAGER_REFRESH_BUTTON' ) . '</button>');?>';
								}
							});							
						}
						
						cont = cont + 1;
						
						if ( percent == 100) {
						
						} else if  ( (cont > 40) && (percent < 90) ) {
							var t = setTimeout("runButton()",75000);
						} else {							
							var t = setTimeout("runButton()",1000);
						}
												
	}
	
	function hideElement(Id) {
		document.getElementById(Id).innerHTML = '';
	}
	
</script>

<?php
if ( empty($this->last_check) ) {
	$this->last_check = Text::_( 'COM_SECURITYCHECK_FILEMANAGER_NEVER' );
}
if ( empty($this->files_status) ) {
	$this->files_status = Text::_( 'COM_SECURITYCHECK_FILEMANAGER_NOT_DEFINED' );
}
?>

<form action="<?php echo Route::_('index.php?option=com_securitycheck&controller=filemanager');?>" method="post" name="adminForm" id="adminForm">
<?php echo HTMLHelper::_( 'form.token' ); ?>

<div id="header_manual_check">
	<strong><?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_MANUAL_CHECK_HEADER' ); ?></strong>
</div>

<div id="error_message_container" class=" centrado margen-container">
	<div id="error_message">
	</div>	
</div>

<div id="error_button" class=" centrado margen-container">	
</div>

<div id="memory_limit_message" class=" centrado margen-loading texto_14">
	<?php 
		// Extract 'memory_limit' value cutting the last character
		$memory_limit = ini_get('memory_limit');
		$memory_limit = (int) substr($memory_limit,0,-1);
				
		// If $memory_limit value is less or equal than 128, shows a warning if no previous scans have finished
		if ( ($memory_limit <= 128) && ($this->last_check == Text::_( 'COM_SECURITYCHECK_FILEMANAGER_NEVER' )) ) {
			$span = "<span class=\"label label-warning\">";
			echo $span . Text::_('COM_SECURITYCHECK_MEMORY_LIMIT_LOW') . "</span>";
		}
	?>
</div>

<div id="completed_message" class="centrado margen-loading texto_14 color_verde">	
</div>

<div id="warning_message" class="centrado margen-loading texto_14">
	<?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_WARNING_START_MESSAGE' ); ?>
</div>

<div class="centrado">
	<div id="buttonwrapper" class="buttonwrapper">
		<button class="btn btn-primary" type="button" onclick="hideElement('buttonwrapper'); runButton();"><i class="fa fa-fire"></i><?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_START_BUTTON' ); ?></button>
	</div>
</div>
<div id="info-container" class="centrado margen">
	<table summary="File check status" class="table margen" cellspacing="0">
	<tr>
		<td colspan="3" class="text-white bg-success"><?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_CHECK_STATUS' ); ?></td>
	</tr>
	<tr>
		<td class="text-white bg-info"><?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_CHECK_STARTTIME' ); ?></td>
		<td class="text-white bg-info"><?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_CHECK_ENDTIME' ); ?></td>	
		<td class="text-white bg-info"><?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_CHECK_TASK' ); ?></td>
	</tr>
	<tr>
		<td id="start_time"><?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_NEVER' ); ?></td>
		<td id="end_time"><?php echo $this->files_status; ?></td>
		<td id="current_task"><?php echo $this->files_status; ?></td>
	</tr>
	</table>
	<div id="backup-progress">
		<div id="bar" class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
	</div>
	
</div>

<div id="header_check_result" class="margen">
	<strong><?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_CHECK_RESULT_HEADER' ); ?></strong>
</div>
<div id="summarytable" class="centrado margen">
<table summary="File check summary" class="table margen" cellspacing="0">
<tr>
	<td colspan="3" class="text-white bg-sucess"><?php echo Text::_( 'COM_SECURITYCHECK_FILE_CHECK_RESUME' ); ?></td>
</tr>
<tr>
	<td class="text-white bg-dark"><?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_LAST_CHECK' ); ?></td>
	<td class="text-white bg-dark"><?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_FILES_SCANNED' ); ?></td>
	<td class="text-white bg-dark"><?php echo Text::_( 'COM_SECURITYCHECK_FILEMANAGER_FILES_FOLDERS_INCORRECT_PERMISSIONS' ); ?></td>	
</tr>
<tr>
	<td><?php echo $this->last_check; ?></td>
	<td><?php echo $this->files_scanned; ?></td>
	<td><?php echo $this->incorrect_permissions; ?></td>
</tr>  
</table>
</div>

<input type="hidden" name="option" value="com_securitycheck" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="1" />
<input type="hidden" name="controller" value="filemanager" />
</form>