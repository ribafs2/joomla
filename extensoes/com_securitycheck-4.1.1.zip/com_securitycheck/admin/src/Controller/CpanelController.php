<?php
/**
 * @Securitycheck component
 * @copyright Copyright (c) 2011 - Jose A. Luque / Securitycheck Extensions
 * @license   GNU General Public License version 3, or later
 */
 
namespace SecuritycheckExtensions\Component\Securitycheck\Administrator\Controller;

// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

use Joomla\CMS\Factory;
use Joomla\Registry\Registry;
use Joomla\CMS\Session\Session;
use SecuritycheckExtensions\Component\Securitycheck\Administrator\Controller\SecuritycheckBaseController;


/**
 * The Control Panel controller class
 *
 */
class CpanelController extends SecuritycheckBaseController
{
	
	/**
	 * Displays the Control Panel 
	 */
	public function display($cachable = false, $urlparams = Array())
	{
		
	}

	/* Acciones al pulsar el bot�n para establecer 'Easy Config' */
	function Set_Easy_Config(){
		$model = $this->getModel("cpanel");
	
		$applied = $model->Set_Easy_Config();
		
		echo $applied;
	}
	
	/* Acciones al pulsar el bot�n para establecer 'Default Config' */
	function Set_Default_Config(){
		$model = $this->getModel("cpanel");
	
		$applied = $model->Set_Default_Config();
		
		echo $applied;
	}
	
	/* Acciones al pulsar el bot�n 'Disable' de Update database */
	function disable_update_database(){
		$model = $this->getModel("cpanel");
		$model->disable_plugin('update_database');
		
		$this->setRedirect( 'index.php?option=com_securitycheck' );
		
	}
	
	/* Acciones al pulsar el bot�n 'Enable' de Update database */
	function enable_update_database(){
		$model = $this->getModel("cpanel");
		$model->enable_plugin('update_database');
		
		$this->setRedirect( 'index.php?option=com_securitycheck' );
		
	}
	
	/* Hace una consulta a la tabla especificada como par�metro */
	public function load($key_name)
	{
		$db = Factory::getDBO();
		$query = $db->getQuery(true);
		$query 
			->select($db->quoteName('storage_value'))
			->from($db->quoteName('#__securitycheck_storage'))
			->where($db->quoteName('storage_key').' = '.$db->quote($key_name));
		$db->setQuery($query);
		$res = $db->loadResult();
			
		$this->config = new Registry();
		
		if(!empty($res)) {
			$res = json_decode($res, true);
			$this->config->loadArray($res);
		}
	}
	
	/* Acciones al pulsar el bot�n para exportar la configuraci�n */
	function Export_config(){		
		$db = Factory::getDBO();
	
		// Obtenemos los valores de las distintas opciones del Firewall Web
		$query = $db->getQuery(true)
			->select(array('*'))
			->from($db->quoteName('#__securitycheck_storage'));
		$db->setQuery($query);
		$params = $db->loadAssocList();
			
		// Extraemos los valores de los array...
		$json_string = array_values($params);
		// ...Y los codificamos en formato json
		$json_string = json_encode($json_string);
		
		// Cargamos los par�metros del Control Center porque necesitamos eliminar su clave secreta
		$this->load("controlcenter");
		
		// Buscamos si el campo ha sido configurado
		$secret_key = $this->config->get("secret_key", false);
						
		// Si ha sido configurado, buscamos su valor en el string_json y lo borramos
		if ( $secret_key ) {
			$json_string = str_replace($secret_key,"",$json_string);
		}
									
		// Mandamos el contenido al navegador
		@ob_end_clean();	
		ob_start();	
		header( 'Content-Type: text/plain' );
		header( 'Content-Disposition: attachment;filename=securitycheck_export.txt' );
		print $json_string;
		exit();
		
	}
	
/* Redirecciona las peticiones a System Info */
function Go_system_info()
{
	$this->setRedirect( 'index.php?option=com_securitycheck&view=sysinfo&'. Session::getFormToken() .'=1' );
}

/* Acciones al pulsar el boton 'Enable' del Spam Protection */
	function enable_spam_protection(){
		$model = $this->getModel("cpanel");
		$model->enable_plugin('spam_protection');
		
		$this->setRedirect( 'index.php?option=com_securitycheck' );
		
	}
	
	/* Acciones al pulsar el botn 'Disable' de Spam Protection */
	function disable_spam_protection(){
		$model = $this->getModel("cpanel");
		$model->disable_plugin('spam_protection');
		
		$this->setRedirect( 'index.php?option=com_securitycheck' );
		
	}

}