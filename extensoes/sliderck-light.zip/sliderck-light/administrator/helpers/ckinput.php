<?php
namespace Sliderck;

defined('_JEXEC') or die;

class CKInput extends  \Joomla\CMS\Input\Input {
	
}
