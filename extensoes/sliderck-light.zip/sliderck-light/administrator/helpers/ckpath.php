<?php
namespace Sliderck;

defined('_JEXEC') or die;

jimport('joomla.filesystem.file');

class CKPath extends \Joomla\CMS\Filesystem\Path {
	
}
