<?php
namespace Sliderck;

defined('_JEXEC') or die;

class CKUri extends \Joomla\CMS\Uri\Uri {
	
}
