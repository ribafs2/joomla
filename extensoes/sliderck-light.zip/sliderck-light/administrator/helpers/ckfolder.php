<?php
namespace Sliderck;

defined('_JEXEC') or die;

jimport('joomla.filesystem.folder');

class CKFolder extends \Joomla\CMS\Filesystem\Folder {
	
}
