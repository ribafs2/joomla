<?php
namespace Sliderck;

defined('_JEXEC') or die;

class CKText extends \Joomla\CMS\Language\Text {
	
}
