<?php
namespace Sliderck;

defined('_JEXEC') or die;

jimport('joomla.filesystem.file');

class CKFile extends \Joomla\CMS\Filesystem\File {
	
}
