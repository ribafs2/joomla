<?php

/**
 * @copyright	Copyright (C) 2011 Cedric KEIFLIN alias ced1870
 * https://www.joomlack.fr
 * @license		GNU/GPL
 * */
// no direct access
defined('_JEXEC') or die('Restricted access');

require_once JPATH_ADMINISTRATOR . '/components/com_sliderck/helpers/ckframework.php';
require_once JPATH_ADMINISTRATOR . '/components/com_sliderck/helpers/helper.php';

Sliderck\CKFramework::load();
SliderckHelper::loadCkbox();

\Joomla\CMS\Language\Text::script('SLIDERCK_ADDSLIDE');
\Joomla\CMS\Language\Text::script('SLIDERCK_SELECTIMAGE');
\Joomla\CMS\Language\Text::script('SLIDERCK_SELECT_LINK');
\Joomla\CMS\Language\Text::script('SLIDERCK_REMOVE2');
\Joomla\CMS\Language\Text::script('SLIDERCK_SELECT');
\Joomla\CMS\Language\Text::script('SLIDERCK_CAPTION');
\Joomla\CMS\Language\Text::script('SLIDERCK_USETOSHOW');
\Joomla\CMS\Language\Text::script('SLIDERCK_IMAGE');
\Joomla\CMS\Language\Text::script('SLIDERCK_VIDEO');
\Joomla\CMS\Language\Text::script('SLIDERCK_TEXTOPTIONS');
\Joomla\CMS\Language\Text::script('SLIDERCK_IMAGEOPTIONS');
\Joomla\CMS\Language\Text::script('SLIDERCK_LINKOPTIONS');
\Joomla\CMS\Language\Text::script('SLIDERCK_VIDEOOPTIONS');
\Joomla\CMS\Language\Text::script('SLIDERCK_ALIGNEMENT_LABEL');
\Joomla\CMS\Language\Text::script('SLIDERCK_TOPLEFT');
\Joomla\CMS\Language\Text::script('SLIDERCK_TOPCENTER');
\Joomla\CMS\Language\Text::script('SLIDERCK_TOPRIGHT');
\Joomla\CMS\Language\Text::script('SLIDERCK_MIDDLELEFT');
\Joomla\CMS\Language\Text::script('SLIDERCK_CENTER');
\Joomla\CMS\Language\Text::script('SLIDERCK_MIDDLERIGHT');
\Joomla\CMS\Language\Text::script('SLIDERCK_BOTTOMLEFT');
\Joomla\CMS\Language\Text::script('SLIDERCK_BOTTOMCENTER');
\Joomla\CMS\Language\Text::script('SLIDERCK_BOTTOMRIGHT');
\Joomla\CMS\Language\Text::script('SLIDERCK_LINK');
\Joomla\CMS\Language\Text::script('SLIDERCK_TARGET');
\Joomla\CMS\Language\Text::script('SLIDERCK_SAMEWINDOW');
\Joomla\CMS\Language\Text::script('SLIDERCK_NEWWINDOW');
\Joomla\CMS\Language\Text::script('SLIDERCK_VIDEOURL');
\Joomla\CMS\Language\Text::script('SLIDERCK_REMOVE');
\Joomla\CMS\Language\Text::script('SLIDERCK_IMPORTFROMFOLDER');
\Joomla\CMS\Language\Text::script('SLIDERCK_ARTICLEOPTIONS');
\Joomla\CMS\Language\Text::script('SLIDERCK_SLIDETIME');
\Joomla\CMS\Language\Text::script('SLIDERCK_CLEAR');
\Joomla\CMS\Language\Text::script('SLIDERCK_SELECT');
\Joomla\CMS\Language\Text::script('SLIDERCK_TITLE');
\Joomla\CMS\Language\Text::script('SLIDERCK_STARTDATE');
\Joomla\CMS\Language\Text::script('SLIDERCK_ENDDATE');
\Joomla\CMS\Language\Text::script('SLIDERCK_SAVE');
\Joomla\CMS\Language\Text::script('SLIDERCK_TEXT_CUSTOM');
\Joomla\CMS\Language\Text::script('SLIDERCK_ARTICLE');
\Joomla\CMS\Language\Text::script('SLIDERCK_TEXT');
\Joomla\CMS\Language\Text::script('SLIDERCK_ONLY_PRO');


class JFormFieldCkslidesmanager extends \Joomla\CMS\Form\FormField {

	protected $type = 'ckslidesmanager';

	protected function getInput() {
		// loads the language files from the frontend
		$lang	= \Joomla\CMS\Factory::getLanguage();
		$lang->load('com_sliderck', JPATH_SITE . '/components/com_sliderck', $lang->getTag(), false);
		$lang->load('com_sliderck', JPATH_SITE, $lang->getTag(), false);

		require_once(JPATH_ROOT . '/administrator/components/com_sliderck/helpers/defines.js.php');
		$path = 'media/com_sliderck/assets/elements/ckslidesmanager/';
		\Joomla\CMS\HTML\HTMLHelper::_('jquery.framework');
		// \Joomla\CMS\HTML\HTMLHelper::_('jquery.ui', array('core', 'sortable'));
		\Joomla\CMS\HTML\HTMLHelper::_('script', 'media/com_sliderck/assets/jquery-uick-custom.js');
		\Joomla\CMS\HTML\HTMLHelper::_('script', 'media/com_sliderck/assets/admin.js');
		\Joomla\CMS\HTML\HTMLHelper::_('script', $path . 'ckslidesmanager.js');
		// if (\Sliderck\CKFof::isSite()) {
			// \Joomla\CMS\HTML\HTMLHelper::_('stylesheet', 'media/com_sliderck/assets/front-edition.css');
		// }
		
		\Joomla\CMS\HTML\HTMLHelper::_('stylesheet', 'media/com_sliderck/assets/jquery-ui.min.css');
		\Joomla\CMS\HTML\HTMLHelper::_('stylesheet', $path . 'ckslidesmanager.css');

		$html = '<input name="' . $this->name . '" id="ckslides" type="hidden" value="' . $this->value . '" />'
				. '<div class="ckaddslide ckbutton ckbutton-success" onclick="javascript:ckAddSlide(false, \'top\');"><i class="far fa-plus-square"></i> ' . \Joomla\CMS\Language\Text::_('SLIDERCK_ADDSLIDE') . '</div>'
				. '<ul id="ckslideslist" class="ckinterface" style="clear:both;"></ul>'
				. '<div class="ckaddslide ckbutton ckbutton-success" onclick="javascript:ckAddSlide();"><i class="far fa-plus-square"></i> ' . \Joomla\CMS\Language\Text::_('SLIDERCK_ADDSLIDE') . '</div>';

		return $html;
	}

	protected function getLabel() {

		return '';
	}
}

