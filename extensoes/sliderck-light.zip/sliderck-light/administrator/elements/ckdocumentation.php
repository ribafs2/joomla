<?php

/**
 * @copyright	Copyright (C) 2011 Cedric KEIFLIN alias ced1870
 * https://www.joomlack.fr
 * @license		GNU/GPL
 * */
// no direct access
defined('_JEXEC') or die('Restricted access');

class JFormFieldCkdocumentation extends \Joomla\CMS\Form\FormField {

	protected $type = 'ckdocumentation';

	protected function getLabel() {
		return '';
	}

	protected function getInput() {
		$html = array();

		$icon = $this->element['icon'] ? $this->element['icon'] : 'file-alt';
		$url = $this->element['url'] ? $this->element['url'] : 'https://www.joomlack.fr/en/documentation';
		$html[] = '<div class="ckinfo"><i class="fas fa-' . $icon . '"></i><a href="' . $url . '" target="_blank">' . \Joomla\CMS\Language\Text::_('SLIDERCK_DOCUMENTATION') . '</a></div>';

		return implode('', $html);
	}
}

