<?php
/* ======================================================
 # Failed Login Attempts for Joomla! - v2.5.5 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v4.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://www.web357.com/product/failed-login-attempts-joomla-plugin
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
use Joomla\CMS\Plugin\CMSPlugin;
class plgSystemFailedLoginAttempts extends CMSPlugin
{
}