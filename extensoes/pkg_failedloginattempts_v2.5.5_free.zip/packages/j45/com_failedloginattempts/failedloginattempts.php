<?php
/* ======================================================
 # Failed Login Attempts for Joomla! - v2.5.5 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v4.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://www.web357.com/product/failed-login-attempts-joomla-plugin
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */
// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\PluginHelper;

// BEGIN: Check if Web357 Framework plugin exists

if (!PluginHelper::isEnabled('system', 'web357framework')) {
    $web357framework_required_msg = Text::_('<p>The <strong>"Web357 Framework"</strong> is required for this extension and must be active. Please, download and install it from <a href="http://downloads.web357.com/?item=web357framework&type=free">here</a>. It\'s FREE!</p>');
    Factory::getApplication()->enqueueMessage($web357framework_required_msg, 'warning');
    return false;
}
// END: Check if Web357 Framework plugin exists

// Access check.
if (!Factory::getUser()->authorise('core.manage', 'com_failedloginattempts'))
{
	throw new Exception(Text::_('JERROR_ALERTNOAUTHOR'));
}

// Include dependancies
jimport('joomla.application.component.controller');

JLoader::registerPrefix('Failedloginattempts', JPATH_COMPONENT_ADMINISTRATOR);
JLoader::register('FailedloginattemptsHelper', JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'failedloginattempts.php');

$controller = BaseController::getInstance('Failedloginattempts');
$controller->execute(Factory::getApplication()->input->get('task'));
$controller->redirect();
