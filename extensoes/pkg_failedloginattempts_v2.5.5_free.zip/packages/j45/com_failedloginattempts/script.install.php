<?php
/* ======================================================
 # Failed Login Attempts for Joomla! - v2.5.5 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v4.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://www.web357.com/product/failed-login-attempts-joomla-plugin
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\BaseController;

require_once __DIR__ . '/script.install.helper.php';

class Com_FailedloginattemptsInstallerScript extends Com_FailedloginattemptsInstallerScriptHelper
{
	public $name           	= 'Failed Login Attempts (Free version)';
	public $alias          	= 'failedloginattempts';
	public $extension_type 	= 'component';

    public function onAfterInstall($route)
	{
		$this->createTable();
		$this->alterTable();
		$this->transferSettingsFromAuthenticationPluginToTheComponent();
		$this->fixAuthenticationPluginOrdering();
	}

	public function uninstall($adapter)
	{
		$this->dropTable();
	}

	private function createTable()
	{
		$query = "CREATE TABLE IF NOT EXISTS `#__failed_login_attempts_logs` (
			`id` int(11) NOT NULL AUTO_INCREMENT,
			`ip_address` varchar(45) NOT NULL,
			`name` varchar(100) NOT NULL,
			`username` varchar(100) NOT NULL,
			`password` varchar(100) NOT NULL,
			`datetime` datetime NOT NULL,
			`country` varchar(100) NOT NULL,
			`browser` varchar(255) NOT NULL,
			`operating_system` varchar(255) NOT NULL,
			`status` varchar(255) NOT NULL,
			`where` varchar(15) NOT NULL,
			PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;";
		$this->db->setQuery($query);
		$this->db->execute();
	}
	
	private function dropTable()
	{
		// connect to db
		$db = Factory::getDBO();

		// Check first if the table exists
		$query = "SHOW TABLES LIKE '" . $db->getPrefix() . "failed_login_attempts_logs'";
		$db->setQuery($query);
		$table_exist = $db->loadResult();
		if ($table_exist)
		{
			$query = "DROP TABLE `#__failed_login_attempts_logs`";
			$db->setQuery($query);
			$db->execute();
		}
    }

	private function alterTable()
	{
		// Check first if the column exists
		$query = "SHOW COLUMNS FROM `" . $this->db->getPrefix() . "failed_login_attempts_logs` LIKE 'name'";
		$this->db->setQuery($query);
		$has_field = $this->db->loadResult();
		if (!$has_field)
		{
			// Then, add column
			$query = 'ALTER TABLE ' . $this->db->quoteName('#__failed_login_attempts_logs') . ' ADD ' . $this->db->quoteName('name') . ' VARCHAR(255) NOT NULL' . ' AFTER ' . $this->db->quoteName('ip_address') . ';';
			$this->db->setQuery($query);
			$this->db->execute();
		}

		// Check first if the column exists
		$query = "SHOW COLUMNS FROM `" . $this->db->getPrefix() . "failed_login_attempts_logs` LIKE 'where'";
		$this->db->setQuery($query);
		$has_field = $this->db->loadResult();
		if (!$has_field)
		{
			// Then, add column
			$query = 'ALTER TABLE ' . $this->db->quoteName('#__failed_login_attempts_logs') . ' ADD ' . $this->db->quoteName('where') . ' VARCHAR(255) NOT NULL' . ' AFTER ' . $this->db->quoteName('status') . ';';
			$this->db->setQuery($query);
			$this->db->execute();
		}
	}

	public function transferSettingsFromAuthenticationPluginToTheComponent()
	{
		// Get the parameters from the com_failedloginattempts
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select($db->qn('e.params'));
		$query->from('#__extensions AS e');
		$query->where($db->qn('e.name').' = '.$db->q('COM_FAILEDLOGINATTEMPTS'));
		$query->where($db->qn('e.type').' = '.$db->q('component'));
		$query->where($db->qn('e.element').' = '.$db->q('com_failedloginattempts'));

		try
		{
			$db->setQuery($query);
			$com_failedloginattempts_parameters = $db->loadResult();
		}
		catch (RuntimeException $e)
		{
			JError::raiseError(500, $e->getMessage());
			return false;
		}

		// Get the parameters from the plg_authentication_failedloginattempts
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select($db->qn('e.params'));
		$query->from('#__extensions AS e');
		$query->where($db->qn('e.name').' = '.$db->q('PLG_AUTHENTICATION_FAILEDLOGINATTEMPTS'));
		$query->where($db->qn('e.type').' = '.$db->q('plugin'));
		$query->where($db->qn('e.element').' = '.$db->q('failedloginattempts'));
		$query->where($db->qn('e.folder').' = '.$db->q('authentication'));

		try
		{
			$db->setQuery($query);
			$plg_authentication_failedloginattempts_parameters = $db->loadResult();
		}
		catch (RuntimeException $e)
		{
			JError::raiseError(500, $e->getMessage());
			return false;
		}

		// Check if the plugin parameters is a valid JSON
		if (!empty($plg_authentication_failedloginattempts_parameters) && $this->isJson($plg_authentication_failedloginattempts_parameters) === FALSE)
		{
			JError::raiseError(500, "Error while transfering the parameters. The parameters of the plg_authentication_failedloginattempts is not a valid JSON. Please, check again the plugin parameters or contact us at support@web357.com to take a quick look.");
			return false;
		}

		// Copy the parameters to the com_failedloginattempts
		if (!empty($plg_authentication_failedloginattempts_parameters) && $com_failedloginattempts_parameters == '{}')
		{
			$db = Factory::getDbo();
			$query = $db->getQuery(true);
			$fields = array(
				$db->qn('params') . ' = ' . $db->q($plg_authentication_failedloginattempts_parameters),
			);
			$conditions = array(
				$db->qn('name') . ' = ' . $db->q('COM_FAILEDLOGINATTEMPTS'),
				$db->qn('type') . ' = ' . $db->q('component'),
				$db->qn('element') . ' = ' . $db->q('com_failedloginattempts'),
			);
			
			try
			{
				$query->update($db->qn('#__extensions'))->set($fields)->where($conditions);
				$db->setQuery($query);
				$db->execute();

				Factory::getApplication()->enqueueMessage(Text::_('The migration has been completed successfully. All the plugin settings have been moved to the component settings.'));
			}
			catch (RuntimeException $e)
			{
				JError::raiseError(500, $e->getMessage());
				return false;
			}
		}

		return true;
	}

	/**
	 * Validate JSON
	 *
	 * @param [type] $string
	 * @return boolean
	 */
	private function isJson($string) 
	{
		json_decode($string);
		return (json_last_error() == JSON_ERROR_NONE);
	}

	/**
	 * Ensure that the plg_authentication_failedloginattempts is first on the list of other authentication plugins
	 *
	 * @return void
	 */
	public function fixAuthenticationPluginOrdering()
	{
		$fix_order = array(
			'failedloginattempts',
			'ldap',
			'joomla',
			'gmail',
			'cookie'
		);

		$plugins = $this->getAuthenticationPlugins();

		$authentication_plugins = array_values(array_filter($fix_order,
			function($aVal) use ($plugins)
			{
				return (array_key_exists($aVal, $plugins));
			}
		));

		$offset = count($plugins) - count($authentication_plugins);

		$cid   = array();
		$order = array();

		foreach ($plugins as $key => $value)
		{
			if (in_array($key, $authentication_plugins))
			{
				$value['ordering'] = $offset + 1 + array_search($key, $authentication_plugins);
			}
			elseif ($value['ordering'] >= $offset)
			{
				$value['ordering'] = 99;
			}

			$cid[]   = $value['extension_id'];
			$order[] = $value['ordering'];
		}

		if (version_compare(JVERSION, '4.0', 'ge'))
		{
			// j4
			ArrayHelper::toInteger($cid);
			ArrayHelper::toInteger($order);
		}
		else
		{
			JArrayHelper::toInteger($cid);
			JArrayHelper::toInteger($order);
		}

		$fix_order          = array();
		$fix_order['cid']   = $cid;
		$fix_order['order'] = $order;

		$controller = new BaseController;

		$controller->addModelPath(JPATH_ADMINISTRATOR . '/components/com_plugins/models', 'PluginsModel');
		$plugin_model = $controller->getModel('Plugin', 'PluginsModel');

		$saved = $plugin_model->saveorder($fix_order['cid'], $fix_order['order']);

		if ($saved === FALSE)
		{
			Factory::getApplication()->enqueueMessage(Text::sprintf('JLIB_APPLICATION_ERROR_REORDER_FAILED', $plugin_model->getError()), 'error');
			return false;
		}
		
		Factory::getApplication()->enqueueMessage(Text::_('The plugin "plg_authentication_failedloginattempts" has been moved to the top of the list of other authentication plugins.'));
		return true;
	}

	/**
	 * Get Authentication Plugins
	 *
	 * @return void
	 */
	protected function getAuthenticationPlugins()
	{
		$db    = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select($db->quoteName(array('extension_id', 'ordering', 'element')))
				->from($db->quoteName('#__extensions'))
				->where(array(
						$db->quoteName('type') . ' = ' . $db->quote('plugin'),
						$db->quoteName('folder') . ' = ' . $db->quote('authentication')
						), 'AND');

		$db->setQuery($query);

		return $db->loadAssocList('element');
	}
}