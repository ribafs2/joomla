<?php
/* ======================================================
 # Failed Login Attempts for Joomla! - v2.5.5 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v4.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://www.web357.com/product/failed-login-attempts-joomla-plugin
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Form\FormField;

require_once('elements_helper.php');

class JFormFieldfixordering extends FormField {
	
	protected $type = 'fixordering';
	
	public function __construct($form = null)
	{
		parent::__construct($form);
		if (Factory::getApplication()->input->get('fixordering')):
			$this->fixOrdering();
		endif;
	}
	
	protected function getInput()
	{
		return ' ';
	}
	
	protected static function flaRedirect($controller)
	{
		$uri = clone Uri::getInstance();
		$uri->delVar('fixordering');
		$uri->delVar('status');
		$uri->delVar('msg');
		$uri->delVar('dir');
		$uri->delVar('cnt');
		$controller->setRedirect($uri->toString());
		$controller->redirect();
	}
	
	protected static function getPlugins()
	{
		$db    = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select($db->quoteName(array('extension_id', 'ordering', 'element')))
				->from($db->quoteName('#__extensions'))
				->where(array(
						$db->quoteName('type') . ' = ' . $db->quote('plugin'),
						$db->quoteName('folder') . ' = ' . $db->quote('authentication')
						), 'AND');

		$db->setQuery($query);

		return $db->loadAssocList('element');
	}
	
	protected function getLabel()
	{
		$html = '';
		$current_url = Uri::getInstance()->toString();

		// display the fixordering button
		$html .= '<p>';
		$html .= Text::_('PLG_FLA_FIX_ORDERING_DESC');
		$html .= '</p>';
		$html .= '<p>';
		$html .= '<span class="editlinktip hasTip" title="'.Text::_('PLG_FLA_FIX_ORDERING_BTN_DESC').'" >';
		$html .= '<a href="'.$current_url.'&fixordering=1" class="btn btn-success btn-lg"><i class="icon-checkmark"></i> '.Text::_('PLG_FLA_FIX_ORDERING_BTN_LBL').'</a> ';
		$html .= '</span>';
		$html .= '</p>';
	
		return $html;			
	}
	
	public static function fixOrdering()
	{
		$fix_order = array(
				'failedloginattempts',
				'ldap',
				'joomla',
				'gmail',
				'cookie'
		);

		$plugins = self::getPlugins();

		$authentication_plugins = array_values(array_filter($fix_order,
				function($aVal) use ($plugins)
				{
					return (array_key_exists($aVal, $plugins));
				}
		));

		$offset = count($plugins) - count($authentication_plugins);

		$cid   = array();
		$order = array();

		foreach ($plugins as $key => $value)
		{
				if (in_array($key, $authentication_plugins))
				{
					$value['ordering'] = $offset + 1 + array_search($key, $authentication_plugins);
				}
				elseif ($value['ordering'] >= $offset)
				{
					$value['ordering'] = 99;
				}

				$cid[]   = $value['extension_id'];
				$order[] = $value['ordering'];
		}

		if (version_compare(JVERSION, '4.0', 'ge'))
		{
			// j4
			ArrayHelper::toInteger($cid);
			ArrayHelper::toInteger($order);
		}
		else
		{
			JArrayHelper::toInteger($cid);
			JArrayHelper::toInteger($order);
		}

		$fix_order          = array();
		$fix_order['cid']   = $cid;
		$fix_order['order'] = $order;

		$controller = new BaseController;

		$controller->addModelPath(JPATH_ADMINISTRATOR . '/components/com_plugins/models', 'PluginsModel');
		$plugin_model = $controller->getModel('Plugin', 'PluginsModel');

		$saved = $plugin_model->saveorder($fix_order['cid'], $fix_order['order']);

		if ($saved === FALSE)
		{
			$controller->setMessage(Text::sprintf('JLIB_APPLICATION_ERROR_REORDER_FAILED', $plugin_model->getError()), 'error');
		}
		else
		{
			$controller->setMessage(Text::_('JLIB_APPLICATION_SUCCESS_ORDERING_SAVED'));
		}

		self::flaRedirect($controller);
	}
}