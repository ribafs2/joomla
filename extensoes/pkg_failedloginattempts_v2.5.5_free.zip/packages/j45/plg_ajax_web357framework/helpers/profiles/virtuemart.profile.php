<?php
/* ======================================================
 # Web357 Framework for Joomla! - v1.9.2 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v4.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://demo.web357.com/joomla/
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */

defined('_JEXEC') or die; 
 
require_once __DIR__ . '/default.php';

class virtuemartProfile extends defaultProfile {

    public static $database_table = [
        [
            '__table__' => 'k2_items',
            '__key__' => 'id',
            '__columns__' => [
                'id',
                'published',
                'trash',
                'introtext',
                'fulltext'
            ],
            '__methods__' => [
                'sql_query' => [
                    'allowed_loops' => '',
                    'method' => 'sql_query__k2__items',
                ],
            ]
        ],
        [
            '__table__' => 'k2_categories',
            '__key__' => 'id',
            '__columns__' => [
                'id',
                'published',
                'trash',
                'description'
            ],
            '__methods__' => [
                'sql_query' => [
                    'allowed_loops' => '1',
                    'method' => 'sql_query__k2__categories',
                ],
            ]
        ]
    ];

    public static function __init_query($_db, $_query, $_files, $_database_loop_index) {
        /** START:: Check if database exist in array */
            try {
                if (count(self::$database_table[$_database_loop_index]) < 1) {
                    return $_query;
                }
            } catch(\Exception $e) {
                return $_query;
            }
        /** END:: Check if database exist in array */
        $_query->select($_db->quoteName(self::$database_table[$_database_loop_index]['__columns__']));
        $_query->from($_db->quoteName('#__'.self::$database_table[$_database_loop_index]['__table__']));
        foreach($_files as $file_key => $file_value) {
            //Clean slashes from the start in case in the database the file is saved without slash.
            $cleanedSubpath = ltrim($file_value->subpath, '/');
            self::{self::$database_table[$_database_loop_index]['__methods__']['sql_query']['method']}($_db, $_query, $cleanedSubpath, $_database_loop_index);
            /** START:: Check if query is the same for all files, so it won't repeat multiple times */
                if (self::$database_table[$_database_loop_index]['__methods__']['sql_query']['allowed_loops'] == '1') {
                    break;
                }
            /** END:: Check if query is the same for all files, so it won't repeat multiple times */
        }
        return $_query;
    }

    public static function sql_query__k2__items($db, $query, $cleanedSubpath, $_database_loop_index) {
        $__cleanedSubpath__basename = basename($cleanedSubpath);
        //Check if filename matches to md5 hash
        if (preg_match('/^[a-f0-9]{32}/', $__cleanedSubpath__basename)) {
            $query->where($db->quote($__cleanedSubpath__basename) . ' LIKE ' . ' CONCAT("%", MD5(CONCAT("Image",' . self::$database_table[$_database_loop_index]['__key__'] . ')), "%")', 'OR');
        }
        foreach (self::$database_table[$_database_loop_index]['__columns__'] as $column_key => $column_value) {
            $query->where('REPLACE(' . $db->quoteName($column_value) . ', '.$db->quote('\\').', "") LIKE ' . $db->quote('%'.$cleanedSubpath.'%'), 'OR');
        }
        return $query;
    }

    public static function sql_query__k2__categories($db, $query, $cleanedSubpath, $_database_loop_index) {
        $query->where($db->quoteName('image') . ' LIKE ' . ' CONCAT("%", ' . self::$database_table[$_database_loop_index]['__key__'] . ', ".", "%")', 'OR');
        return $query;
    }

    public static function __format_results($_files, $_database_found_results, $_database_loop_index) {
        $formatedFoundData = [];
        foreach($_files as $file_key => $file_value) {
            $cleanedSubpath = ltrim($file_value->subpath, '/');
            $__db_result_map__temp = [];
            if (strpos($cleanedSubpath, 'media/k2/items') > -1) {
                $__db_result_map__temp = self::__format_results__k2__items($cleanedSubpath, $_database_found_results, $_database_loop_index);
                if (count($__db_result_map__temp)) {
                    $formatedFoundData[$cleanedSubpath] = $__db_result_map__temp;
                }
            } elseif (strpos($cleanedSubpath, 'media/k2/categories') > -1) {
                $__db_result_map__temp = self::__format_results__k2__categories($cleanedSubpath, $_database_found_results, $_database_loop_index);
                if (count($__db_result_map__temp)) {
                    $formatedFoundData[$cleanedSubpath] = $__db_result_map__temp;
                }
            }
        }
        return $formatedFoundData;
    }

    public static function __format_results__k2__items($cleanedSubpath, $_database_found_results, $_database_loop_index) {
        $__cleanedSubpath__basename = basename($cleanedSubpath);
        $__db_result_map__temp = [];
        foreach($_database_found_results as $item_key => $item_value) {
            $__columns_found = [];
            /** START:: Check if filename matches - to MD5 Hash */
                if (preg_match('/^[a-f0-9]{32}/', $__cleanedSubpath__basename)) {
                    if (strpos($__cleanedSubpath__basename, MD5('Image'.$item_value->{self::$database_table[$_database_loop_index]['__key__']})) > -1) {
                        $__columns_found[] = self::$database_table[$_database_loop_index]['__key__'];
                    }
                }
            /** END:: Check if filename matches - to MD5 Hash */
            //Check if file was found in any column
            if (count($__columns_found) > 0) {
                $__db_result_map__temp[] = [
                    'row_id' => $item_value->{self::$database_table[$_database_loop_index]['__key__']},
                    'table' => self::$database_table[$_database_loop_index]['__table__'],
                    'columns' => $__columns_found,
                    'published' => $item_value->published,
                    'trash' => $item_value->trash
                ];
            }
        }
        return $__db_result_map__temp;
    }

    public static function __format_results__k2__categories($cleanedSubpath, $_database_found_results, $_database_loop_index) {
        $__cleanedSubpath__basename = basename($cleanedSubpath);
        $__db_result_map__temp = [];
        foreach($_database_found_results as $item_key => $item_value) {
            $__columns_found = [];
            /** START:: Check if filename matches */
                $__cleanedSubpath__basename = basename($cleanedSubpath);
                if (strpos($__cleanedSubpath__basename, $item_value->{$table_value->__info__->unique_key_column}.'.') > -1) {
                    $__columns_found[] = 'image';
                }
            /** END:: Check if filename matches */
            //Check if file was found in any column
            if (count($__columns_found) > 0) {
                $__db_result_map__temp[] = [
                    'row_id' => $item_value->{self::$database_table[$_database_loop_index]['__key__']},
                    'table' => self::$database_table[$_database_loop_index]['__table__'],
                    'columns' => $__columns_found,
                    'published' => $item_value->published,
                    'trash' => $item_value->trash
                ];
            }
        }
        return $__db_result_map__temp;
    }

}