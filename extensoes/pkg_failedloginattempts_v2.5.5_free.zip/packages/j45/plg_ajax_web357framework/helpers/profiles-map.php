<?php
/* ======================================================
 # Web357 Framework for Joomla! - v1.9.2 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v4.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://demo.web357.com/joomla/
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */

defined('_JEXEC') or die; 

class ProfilesMap {

    public static function map() {
        $profiles = [
            'k2' => [
                'class' => 'k2Profile'
            ],
            'com_content' => [
                'class' => 'comcontentProfile'
            ]
        ];
        return $profiles;
    }

    public static function checkIfClassExist($profile_slug) {
        $exists = false;
        try {
            if(strlen(self::map()[$profile_slug]['class']) > 0) {
                $exists = true;
            } else {
                $exists = false;
            }
        } catch(\Exception $e) {
            $exists = false;
        }
        return $exists;
    }

}