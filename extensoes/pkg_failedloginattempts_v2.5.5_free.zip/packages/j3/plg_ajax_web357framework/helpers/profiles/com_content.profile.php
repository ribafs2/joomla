<?php
/* ======================================================
 # Web357 Framework for Joomla! - v1.9.2 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v3.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://demo.web357.com/joomla/
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */

defined('_JEXEC') or die; 

require_once __DIR__ . '/default.php';

class comcontentProfile extends defaultProfile {

    public static $database_table = [
        [
            '__table__' => 'categories',
            '__key__' => 'id',
            '__columns__' => [
                'id',
                'published',
                'description',
                'params'
            ],
            '__methods__' => [
                'format' => [
                    'method' => '__format_results__categories'
                ],
                'sql_query' => [
                    'allowed_loops' => '',
                    'method' => 'sql_query__categories',
                ],
            ]
        ],
        [
            '__table__' => 'content',
            '__key__' => 'id',
            '__columns__' => [
                'id',
                'state',
                'introtext',
                'fulltext',
                'images'
            ],
            '__methods__' => [
                'format' => [
                    'method' => '__format_results__content'
                ],
                'sql_query' => [
                    'allowed_loops' => '',
                    'method' => 'sql_query__content',
                ],
            ]
        ]
    ];

    public static function __init_query($db, $query, $_files, $_database_loop_index) {
        /** START:: Check if database exist in array */
            try {
                if (count(self::$database_table[$_database_loop_index]) < 1) {
                    return $query;
                }
            } catch(\Exception $e) {
                return $query;
            }
        /** END:: Check if database exist in array */
        $query->select($db->quoteName(self::$database_table[$_database_loop_index]['__columns__']));
        $query->from($db->quoteName('#__'.self::$database_table[$_database_loop_index]['__table__']));

        if (self::$database_table[$_database_loop_index]['__table__'] == 'categories') {
            $query->where($db->quoteName('extension') . ' = ' . $db->quote('com_content'), 'AND');
        }
        
        $__temp__sql_query = [];
        foreach($_files as $file_key => $file_value) {
            //Clean slashes from the start in case in the database the file is saved without slash.
            $cleanedSubpath = ltrim($file_value->subpath, '/');
            //It works also without "$query =" before the self::{...}. The $query variable keeps getting updated.
            $__temp__sql_query[] = self::{self::$database_table[$_database_loop_index]['__methods__']['sql_query']['method']}($db, $query, $cleanedSubpath, $_database_loop_index);
            /** START:: Check if query is the same for all files, so it won't repeat multiple times */
                if (self::$database_table[$_database_loop_index]['__methods__']['sql_query']['allowed_loops'] == '1') {
                    break;
                }
            /** END:: Check if query is the same for all files, so it won't repeat multiple times */
        }
        $query->where('('.implode(' OR ', $__temp__sql_query).')');
        return $query;
    }

    public static function sql_query__categories($db, $query, $cleanedSubpath, $_database_loop_index) {
        $__cleanedSubpath__basename = basename($cleanedSubpath);
        $__temp__sql_query = [];
        foreach (self::$database_table[$_database_loop_index]['__columns__'] as $column_key => $column_value) {
            $__temp__sql_query[] = 'REPLACE(' . $db->quoteName($column_value) . ', '.$db->quote('\\').', "") LIKE ' . $db->quote('%'.$cleanedSubpath.'%');
        }
        $__temp__sql_query = '('.implode(' OR ', $__temp__sql_query).')';
        return $__temp__sql_query;
    }

    public static function sql_query__content($db, $query, $cleanedSubpath, $_database_loop_index) {
        $__cleanedSubpath__basename = basename($cleanedSubpath);
        $__temp__sql_query = [];

        /** START:: Create the sql query */
            $__temp__sql_query[] = 'REPLACE(' . $db->quoteName('introtext') . ', '.$db->quote('\\').', "") LIKE ' . $db->quote('%'.$cleanedSubpath.'%');
            $__temp__sql_query[] = 'REPLACE(' . $db->quoteName('fulltext') . ', '.$db->quote('\\').', "") LIKE ' . $db->quote('%'.$cleanedSubpath.'%');
            $__temp__sql_query[] = 'REPLACE(' . $db->quoteName('images') . ', '.$db->quote('\\').', "") LIKE ' . $db->quote('%'.$cleanedSubpath.'%');
        /** END:: Create the sql query */
        $__temp__sql_query = '('.implode(' OR ', $__temp__sql_query).')';
        return $__temp__sql_query;
    }

    public static function __format_results($_files, $_database_found_results, $_database_loop_index) {
        $formatedFoundData = [];
        foreach($_files as $file_key => $file_value) {
            $cleanedSubpath = ltrim($file_value->subpath, '/');
            $__db_result_map__temp = [];
            $__db_result_map__temp = self::{self::$database_table[$_database_loop_index]['__methods__']['format']['method']}($cleanedSubpath, $_database_found_results, $_database_loop_index);
            if (count($__db_result_map__temp)) {
                $formatedFoundData[$cleanedSubpath] = $__db_result_map__temp;
            }
        }
        return $formatedFoundData;
    }

    public static function __format_results__categories($cleanedSubpath, $_database_found_results, $_database_loop_index) {
        $__cleanedSubpath__basename = basename($cleanedSubpath);
        $__db_result_map__temp = [];
        foreach($_database_found_results as $item_key => $item_value) {
            $__columns_found = [];
            /** START:: Check column: description */
                if (strpos($item_value->description, $cleanedSubpath) > -1) {
                    $__columns_found[] = 'description';
                }
            /** END:: Check column: description */
            /** START:: Check column: params */
                if (strpos($item_value->params, str_replace('/', '\/', $cleanedSubpath)) > -1) {
                    $__columns_found[] = 'params';
                }
            /** END:: Check column: params */
            //Check if file was found in any column
            if (count($__columns_found) > 0) {
                $__db_result_map__temp[] = [
                    'row_id' => $item_value->{self::$database_table[$_database_loop_index]['__key__']},
                    'table' => self::$database_table[$_database_loop_index]['__table__'],
                    'columns' => $__columns_found,
                    'published' => $item_value->published,
                    'trash' => 'not-exist'
                ];
            }
        }
        return $__db_result_map__temp;
    }

    public static function __format_results__content($cleanedSubpath, $_database_found_results, $_database_loop_index) {
        $__cleanedSubpath__basename = basename($cleanedSubpath);
        $__db_result_map__temp = [];
        foreach($_database_found_results as $item_key => $item_value) {
            $__columns_found = [];
            /** START:: Check column: introtext */
                if (strpos($item_value->introtext, $cleanedSubpath) > -1) {
                    $__columns_found[] = 'introtext';
                }
            /** END:: Check column: introtext */
            /** START:: Check column: fulltext */
                if (strpos($item_value->fulltext, str_replace('/', '\/', $cleanedSubpath)) > -1) {
                    $__columns_found[] = 'fulltext';
                }
            /** END:: Check column: fulltext */
            /** START:: Check column: images */
                if (strpos($item_value->images, str_replace('/', '\/', $cleanedSubpath)) > -1) {
                    $__columns_found[] = 'images';
                }
            /** END:: Check column: images */
            //Check if file was found in any column
            if (count($__columns_found) > 0) {
                $__db_result_map__temp[] = [
                    'row_id' => $item_value->{self::$database_table[$_database_loop_index]['__key__']},
                    'table' => self::$database_table[$_database_loop_index]['__table__'],
                    'columns' => $__columns_found,
                    'published' => $item_value->published,
                    'trash' => 'not-exist'
                ];
            }
        }
        return $__db_result_map__temp;
    }

}