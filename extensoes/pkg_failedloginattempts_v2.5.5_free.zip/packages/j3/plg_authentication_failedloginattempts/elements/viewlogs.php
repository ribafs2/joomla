<?php
/* ======================================================
 # Failed Login Attempts for Joomla! - v2.5.5 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v3.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://www.web357.com/product/failed-login-attempts-joomla-plugin
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Form\FormField;

require_once('elements_helper.php');

class JFormFieldviewlogs extends FormField {
	
	protected $type = 'viewlogs';

	protected function getInput()
	{
		// load the modal behavior to display the logs
		HTMLHelper::_('behavior.modal');  

		// some useful vars
		$html = '';
		$db = Factory::getDbo();
		$current_url = Uri::getInstance()->toString();
		$live_site_url = Uri::base();
		$live_site_url = str_replace('administrator/', '', $live_site_url);
		$path_to_logs = $live_site_url.'plugins/authentication/failedloginattempts/elements/viewlogs.php';
		$current_url = Uri::getInstance()->toString();
		
		// BEGIN: Get the logs from db
		// data from db
		$query = $db->getQuery(true);
		$query
			->select('*')
			->from($db->quoteName('#__failed_login_attempts_logs'));
		$db->setQuery($query);
		$log_results = $db->loadObjectList();

		// create the html table (css credits: http://johnsardine.com/freebies/dl-html-css/simple-little-tab/)
		$print_logs  = '';
		$print_logs .= '<table cellspacing="0" width="95%" class="w357_modal_table">';
		$print_logs .= '<thead>';
		$print_logs .= '<tr>';
		$print_logs .= '<th>'.Text::_('PLG_FLA_WHERE_LBL').'</th><th>'.Text::_('PLG_FLA_IP_LBL').'</th><th>'.Text::_('PLG_FLA_NAME_LBL').'</th><th>'.Text::_('PLG_FLA_USERNAME_LBL').'</th><th>'.Text::_('PLG_FLA_PASS_LBL').'</th><th>'.Text::_('PLG_FLA_DATETIME_LBL').'</th><th>'.Text::_('PLG_FLA_STATUS').'</th>';
		$print_logs .= '<th>'.Text::_('PLG_FLA_COUNTRY_LBL').'</th><th>'.Text::_('PLG_FLA_BROWSER_LBL').'</th><th>'.Text::_('PLG_FLA_OS_LBL').'</th>';
		$print_logs .= '<th>ID</th>';
		$print_logs .= '</tr>';
		$print_logs .= '</thead>';
		
		$print_logs .= '<tbody>';
		if (!empty($log_results)):
			$logs_info_message = '';
			$i=0;
			foreach ($log_results as $result):
				$print_logs .= '<tr class="'.(($i % 2 == 0) ? "odd" : "even").'">';
				$print_logs .= '<td>'.(!empty($result->where) ? Text::_('PLG_FLA_'.strtoupper($result->where)) : 'Unknown').'</td><td>'.$result->ip_address.'</td><td>'.(!empty($result->name) ? $result->name : '---').'</td><td>'.$result->username.'</td><td>'.$result->password.'</td><td>'.$result->datetime.'</td><td>'.$result->status.'</td>';
				$print_logs .= '<td>'.$result->country.'</td><td>'.$result->browser.'</td><td>'.$result->operating_system.'</td>';
				$print_logs .= '<td>'.$result->id.'</td>';
				$print_logs .= '</tr>';
			$i++;
			endforeach;
		else:
			$logs_info_message = '<p class="logs_info_message">'.Text::_('PLG_FLA_NO_LOGS').'</p>';
			$print_logs .= '<tr>';
			$print_logs .= '<td>---</td><td>---</td><td>---</td><td>---</td><td>---</td>';
			$print_logs .= '<td>---</td><td>---</td><td>---</td>';
			$print_logs .= '<td>---</td>';
			$print_logs .= '</tr>';
		endif;;
		$print_logs .= '</tbody>';
		
		$print_logs .= '</table>';
		$print_logs .= $logs_info_message;
		// END: Get the logs from db
		
		// VIEW logs
		$html .= '<div style="display: none"><div id="load_logs">'.$print_logs.'</div></div>';
		
		// View or DELETE (LINKS)
		$html .= '<div class="j357">';
		$html .= '<h3>'.Text::_('PLG_FLA_VIEW_OR_DELETE_LOGS').'</h3>';
		$html .= '<p><a class="modal btn" id="view_logs" href="#load_logs" rel="{size: {x: 1200, y: 500}}"><strong>'.Text::_('PLG_FLA_VIEW_LOGS').'</strong></a> &nbsp;&nbsp; | &nbsp;&nbsp; <a class="btn" href="'.$current_url.'&j357task=delete_logs" onclick="return confirm(\''.Text::_('PLG_FLA_SURE_FOR_DELETE').'\')"><strong>'.Text::_('PLG_FLA_DELETE_LOGS').'</strong></a></p>';
		$html .= '</div>';

		// DELETE logs
		$j357task = Factory::getApplication()->input->get('j357task', '', 'STRING');

		if ($j357task == 'delete_logs'):

			// delete logs from db
			$query = $db->getQuery(true);
			$query->delete($db->quoteName('#__failed_login_attempts_logs'));
			$db->setQuery($query);
			$db->execute();

			// BEGIN: get plugin's id
			$db = Factory::getDbo();
			$query = "SELECT extension_id FROM #__extensions WHERE enabled=1 AND element='failedloginattempts' AND type='plugin' AND folder='authentication'";
			$db->setQuery($query);
			$db->execute();
			$plugin_id = $db->loadResult();
			// END: get plugin's id
		
			// redirect to edit plugin
			$message = Text::_('PLG_FLA_LOGS_DELETED');
			$msg_type = 'message'; 
			$mainframe = Factory::getApplication();
			$mainframe->redirect("index.php?option=com_plugins&view=plugin&layout=edit&extension_id=".$plugin_id."", $message, $msg_type);

		endif;
		
		return $html;		
	}
}