<?php
/* ======================================================
 # Failed Login Attempts for Joomla! - v2.5.5 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v3.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://www.web357.com/product/failed-login-attempts-joomla-plugin
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */
defined('_JEXEC') or die;

use Joomla\CMS\Form\FormField;

require_once('elements_helper.php');

class JFormFieldblockipaddress extends FormField {
	
	protected $type = 'blockipaddress';

	protected function getInput()
	{
		return ' ';
	}
	
	protected function getLabel()
	{
		// print
		$html  = '<div class="j357">';
		$html .= '<h3>BLOCK IP ADDRESSES WITH .HTACCESS</h3>';
		$html .= '<p>If you want to block certain ips from accessing your site, copy the code below to a text file and upload it to your server. Then rename it to ".htaccess"</p>';
		$html .= '<pre>Order Deny,Allow<br>Deny from 123.456.78.9<br>Deny from 456.123.32.4</pre>';
		$html .= '<em>Create your own .htaccess file using <a href="http://www.htaccesstools.com/block-ips/" target="_blank">this</a> useful generator</em>';
		$html .= '</div>';
				
		return $html;		
	}
}