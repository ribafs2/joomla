<?php
/* ======================================================
 # Failed Login Attempts for Joomla! - v2.5.5 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v3.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://www.web357.com/product/failed-login-attempts-joomla-plugin
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Log\Log;
use Joomla\CMS\User\UserHelper;
use Joomla\CMS\Authentication\Authentication;
use Joomla\CMS\Helper\AuthenticationHelper;
use Joomla\CMS\Date\Date;

// BEGIN: Check if Web357 Framework plugin exists
if (!PluginHelper::isEnabled('system', 'web357framework')) {
    $web357framework_required_msg = Text::_('<p>The <strong>"Web357 Framework"</strong> is required for this extension and must be active. Please, download and install it from <a href="http://downloads.web357.com/?item=web357framework&type=free">here</a>. It\'s FREE!</p>');
    Factory::getApplication()->enqueueMessage($web357framework_required_msg, 'warning');
    return false;
}
// END: Check if Web357 Framework plugin exists

class plgAuthenticationFailedLoginAttempts extends CMSPlugin
{
	// get mailfrom from joomla config
	var $mailfrom = '';
	var $fromname = '';

	// get params
	var $enabled_for_backend = '';
	var $enabled_for_frontend = '';
	var $successful_login_attempts = '';
	var $notify_me_by_email = '';
	var $email_address = '';
	var $ip_address = '';
	var $name = '';
	var $username = '';
	var $password = '';
	var $datetime = '';
	var $country = '';
	var $browser = '';
	var $operating_system = '';
	var $email_sbj_succesfully_login_attempt_frontend = '';
	var $email_sbj_pass_not_allowed_frontend = '';
	var $email_sbj_username_and_pass_do_not_match_frontend = '';
	var $email_sbj_login_denied_account_blocked_frontend = '';
	var $email_sbj_succesfully_login_attempt_backend = '';
	var $email_sbj_pass_not_allowed_backend = '';
	var $email_sbj_username_and_pass_do_not_match_backend = '';
	var $email_sbj_login_denied_account_blocked_backend = '';

	// get live site url
	var $live_site_url = '';
	var $current_url = '';

	// Web357 Framework Helper Class
	var $w357frmwrk = '';
	
	function __construct()
	{
		// get mailfrom from joomla config
		$config = Factory::getConfig();
		$this->mailfrom = $config->get('mailfrom');
		$this->fromname = $config->get('fromname');

		// get params
		$this->_params = ComponentHelper::getParams('com_failedloginattempts'); // Get the parameters from the component
		$this->enabled_for_backend = $this->_params->get('enabled_for_backend', '1');
		$this->enabled_for_frontend = $this->_params->get('enabled_for_frontend', '1');
		$this->successful_login_attempts = $this->_params->get('successful_login_attempts', '1');
		$this->notify_me_by_email = $this->_params->get('notify_me_by_email', '1');
		$this->email_address = $this->_params->get('email_address', $this->mailfrom);
		$this->ip_address = $this->_params->get('ip_address', '1');
		$this->name = $this->_params->get('name', '1');
		$this->username = $this->_params->get('username', '1');
		$this->password = $this->_params->get('password', '0');
		$this->datetime = $this->_params->get('datetime', '1');
		$this->country = $this->_params->get('country', '0');
		$this->browser = $this->_params->get('browser', '0');
		$this->operating_system = $this->_params->get('operating_system', '0');
		$this->save_logs_to_db = $this->_params->get('save_logs_to_db', '1');
		$this->email_sbj_succesfully_login_attempt_frontend = $this->_params->get('email_sbj_succesfully_login_attempt_frontend', 'Successful Login Attempt, at Front-end');
		$this->email_sbj_pass_not_allowed_frontend = $this->_params->get('email_sbj_pass_not_allowed_frontend', 'Failed Login Attempt, at Front-end | Empty password not allowed');
		$this->email_sbj_username_and_pass_do_not_match_frontend = $this->_params->get('email_sbj_username_and_pass_do_not_match_frontend', 'Failed Login Attempt, at Front-end | Username and password do not match or you do not have an account yet');
		$this->email_sbj_login_denied_account_blocked_frontend = $this->_params->get('email_sbj_login_denied_account_blocked_frontend', 'Failed Login Attempt, at Front-end | Login denied! Your account has either been blocked or you have not activated it yet');
		$this->email_sbj_succesfully_login_attempt_backend = $this->_params->get('email_sbj_succesfully_login_attempt_backend', 'Successful Login Attempt, at Back-end');
		$this->email_sbj_pass_not_allowed_backend = $this->_params->get('email_sbj_pass_not_allowed_backend', 'Failed Login Attempt, at Back-end | Empty password not allowed');
		$this->email_sbj_username_and_pass_do_not_match_backend = $this->_params->get('email_sbj_username_and_pass_do_not_match_backend', 'Failed Login Attempt, at Back-end | Username and password do not match or you do not have an account yet');
		$this->email_sbj_login_denied_account_blocked_backend = $this->_params->get('email_sbj_login_denied_account_blocked_backend', 'Failed Login Attempt, at Back-end | Login denied! Your account has either been blocked or you have not activated it yet');

		// get live site url
		$this->live_site_url = Uri::base();
		$this->current_url = Uri::getInstance()->toString();

		// Call the Web357 Framework Helper Class
		require_once(JPATH_PLUGINS.DIRECTORY_SEPARATOR.'system'.DIRECTORY_SEPARATOR.'web357framework'.DIRECTORY_SEPARATOR.'web357framework.class.php');
		$this->w357frmwrk = new Web357FrameworkHelperClass;
	}

	/**
	 * Get the (Full) Name by the username.
	 *
	 * @param string $username
	 * @return void
	 */
	private function getNameByUsername($username = '')
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select($db->quoteName('a.name'));
		$query->from($db->quoteName('#__users', 'a'));
		$query->where($db->quoteName('a.username') . ' = '. $db->quote($username));

		$db->setQuery($query);

		try
		{
			return $db->loadResult();
		}
		catch (RuntimeException $e)
		{
			JError::raiseError(500, $e->getMessage());
			return false;
		}

		return 'Unknown';
	}

	function getData($credentials, $message_type = '', $type = "email")
	{
		// get data	
		$ip_address = $_SERVER['REMOTE_ADDR'];
		$username = $credentials['username'];
		$name = $this->getNameByUsername($username);
		$password = (strpos($message_type, 'PLG_FLA_SUCCESSFULLY_LOGIN') !== false) ? str_repeat("*", strlen( $credentials['password'])) : $credentials['password'];
		$datetime = new Date('now', new DateTimeZone(Factory::getConfig()->get('offset')));
		$country = $this->w357frmwrk->getCountry(); // Country
		$browser = $this->w357frmwrk->getBrowser(); // Browser
		$operating_system = $this->w357frmwrk->getOS(); // OS
		$in_backend_frontend = (Factory::getApplication()->isClient('administrator')) ? "Backend" : "Frontend";
		$link_to_pro = '<a href="https://www.web357.com/product/failed-login-attempts-joomla-plugin?utm_source=CLIENT&amp;utm_medium=CLIENT-FLA-ProLink-web357&amp;utm_content=CLIENT-FLA-ProLink&amp;utm_campaign=FLA_radiofelement_free_vs_pro" target="_blank">PRO</a>';

        if ($type == "email") {
           
			// collect data for email
            $data  = "<h3>".Text::_('PLG_FLA_EMAIL_HEADING').":</h3>".
             "<p>".
             "".Text::_('PLG_FLA_EMAIL_MESSAGE_TYPE').": <strong style=\"color: red;\">".Text::_($message_type)."</strong><br>".
             "".Text::_('PLG_FLA_EMAIL_WHERE').": ".Text::_('PLG_FLA_EMAIL_AT')." <strong style=\"color: blue;\">".$in_backend_frontend."</strong> | Url: ".$this->current_url."<br>".
             (($this->ip_address==1) ? "".Text::_('PLG_FLA_EMAIL_IP_ADDRESS').": <strong>".$ip_address."</strong><br>" : "").
             (($this->name==1 && !empty($name)) ? "".Text::_('PLG_FLA_EMAIL_NAME').": <strong>".$name."</strong><br>" : "").
             (($this->username==1) ? "".Text::_('PLG_FLA_EMAIL_USERNAME').": <strong>".$username."</strong><br>" : "").
             (($this->password==1) ? "".Text::_('PLG_FLA_EMAIL_PASSWORD').": <strong>".(!empty($password) ? $password : '---')."</strong><br>" : "").
             (($this->datetime==1) ? "".Text::_('PLG_FLA_EMAIL_DATETIME').": <strong>".$datetime."</strong><br>" : "").
             (($this->country==1) ? "".Text::_('PLG_FLA_EMAIL_COUNTRY').": <strong>".$country."</strong><br>" : "").
             (($this->browser==1) ? "".Text::_('PLG_FLA_EMAIL_BROWSER').": <strong>".$browser."</strong><br>" : "").
             (($this->operating_system==1) ? "".Text::_('PLG_FLA_EMAIL_OPERATING_SYSTEM').": <strong>".$operating_system."</strong>" : "").
             "</p>";

            $data .= "<p><em>".Text::sprintf('PLG_FLA_EMAIL_SOME_DETAILS_ONLY_IN_PRO', $link_to_pro)."</em></p>";

            return $data;
        }
		else
		{
            // collect data for database
            $data_arr = array();
            $data_arr['ip_address'] = ($this->ip_address==1) ? $ip_address : '';
            $data_arr['name'] = ($this->name==1) ? $name : '';
            $data_arr['username'] = ($this->username==1) ? $username : '';
            $data_arr['password'] = ($this->password==1) ? $password : '';
            $data_arr['datetime'] = ($this->datetime==1) ? $datetime : '';
            $data_arr['status'] = $message_type;
            $data_arr['country'] = ($this->country==1) ? $country : '';
            $data_arr['browser'] = ($this->browser==1) ? $browser : '';
            $data_arr['operating_system'] = ($this->operating_system==1) ? $operating_system : '';
            $data_arr = array_filter($data_arr);

            return $data_arr;
        }
	}

	function getEmailbyUsername($username = '')
	{
		if (empty($username))
		{
			return '';
		}

		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$query->select('email');
		$query->from('#__users');
		$query->where($db->quoteName('username').' = '.$db->quote($username));
		$db->setQuery($query);

		try
		{
			return (string) $db->loadResult();
		}
		catch (RuntimeException $e)
		{
			JError::raiseError(500, $e->getMessage());
			return false;
		}
	}

	/**
	 * Where is the login attempt.
	 *
	 * @return void
	 */
	function loginAttemptWhere()
	{
		if (Factory::getApplication()->isClient('site'))
		{
			return 'frontend';
		}
		elseif (Factory::getApplication()->isClient('administrator'))
		{
			return 'backend';
		}

		return 'unknown';
	}
	
	function storeData($credentials, $message_type = '')
	{
		// Load component language file
		$lang = Factory::getLanguage();
		$extension = 'com_failedloginattempts';
		$base_dir = JPATH_ADMINISTRATOR . '/components/' . $extension;
		$lang->load($extension, $base_dir);

		// enabled for backend?
		$is_backend = Factory::getApplication()->isClient('administrator') ? true : false;
		
		// enabled for frontend?
		$is_frontend = Factory::getApplication()->isClient('site') ? true : false;

		// check if is enabled for backend or for frontend
        if (($this->enabled_for_backend && $is_backend) || ($this->enabled_for_frontend && $is_frontend)) {

            // get data
            $get_data_arr = $this->getData($credentials, $message_type, "fordb");
            $ip_address = (!empty($get_data_arr['ip_address'])) ? $get_data_arr['ip_address'] : '';
            $name = (!empty($get_data_arr['name'])) ? $get_data_arr['name'] : '';
            $username = (!empty($get_data_arr['username'])) ? $get_data_arr['username'] : '';
            $email = $this->getEmailbyUsername($username);
            $password = (!empty($get_data_arr['password'])) ? $get_data_arr['password'] : '';
            $datetime = (!empty($get_data_arr['datetime'])) ? $get_data_arr['datetime'] : '';
            $status = (!empty($get_data_arr['status'])) ? $get_data_arr['status'] : '';
            $country = (!empty($get_data_arr['country'])) ? $get_data_arr['country'] : '';
            $browser = (!empty($get_data_arr['browser'])) ? $get_data_arr['browser'] : '';
            $operating_system = (!empty($get_data_arr['operating_system'])) ? $get_data_arr['operating_system'] : '';
            $where = $this->loginAttemptWhere();
            
            // send data to email
            if ($this->notify_me_by_email) {
                $from = $this->mailfrom;
                $fromname = $this->fromname;
                $to = $this->email_address;
                $headers  = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
                $headers .= "From: $from";
                $country_for_mail = (($this->country==1) ? " | Country: ".$this->w357frmwrk->getCountry() : "");
                $get_data = $this->getData($credentials, $message_type, "email");

                $in_backend_frontend = $is_backend ? ", at Backend" : ", at Frontend";

                // Customize the Email subjects
				switch ($message_type) 
				{
					case 'JGLOBAL_AUTH_EMPTY_PASS_NOT_ALLOWED':
                    	$subject = ($is_backend ? $this->email_sbj_pass_not_allowed_backend : $this->email_sbj_pass_not_allowed_frontend);
						break;

					case 'JGLOBAL_AUTH_INVALID_PASS':
                    	$subject = ($is_backend ? $this->email_sbj_username_and_pass_do_not_match_backend : $this->email_sbj_username_and_pass_do_not_match_frontend);
						break;

					case 'JGLOBAL_AUTH_NO_USER':
                    	$subject = ($is_backend ? $this->email_sbj_username_and_pass_do_not_match_backend : $this->email_sbj_username_and_pass_do_not_match_frontend);

						break;

					case 'JERROR_NOLOGIN_BLOCKED':
                    	$subject = ($is_backend ? $this->email_sbj_login_denied_account_blocked_backend : $this->email_sbj_login_denied_account_blocked_frontend);
						break;

					case 'PLG_FLA_SUCCESSFULLY_LOGIN':
                    	$subject = ($is_backend ? $this->email_sbj_succesfully_login_attempt_backend : $this->email_sbj_succesfully_login_attempt_frontend);
						break;
					
					default:
						$subject = Text::_('PLG_FLA_EMAIL_SBJ_FAILED_LOGIN_ATTEMPT').$in_backend_frontend." | ".Text::_($message_type)."".$country_for_mail;
						break;
				}

				// Replace subject's variables
                $subject = str_replace('{ip_address}', $ip_address, $subject);
                $subject = str_replace('{name}', $name, $subject);
                $subject = str_replace('{username}', $username, $subject);
                $subject = str_replace('{email}', $email, $subject);
                $subject = str_replace('{datetime}', $datetime, $subject);
                $subject = str_replace('{country}', $this->w357frmwrk->getCountry(), $subject);
                $subject = str_replace('{browser}', $browser, $subject);
                $subject = str_replace('{operating_system}', $operating_system, $subject);

                // Send email
                $mailer = Factory::getMailer();
                $config = Factory::getConfig();
                $sender = array($from, $fromname);
                    
                $mailer->setSender($sender);
                $mailer->addRecipient($to);
                $mailer->setBody($get_data);
                $mailer->isHTML(true);
                $mailer->Encoding = 'base64';
                $mailer->setSubject($subject);

				try
				{
					$mailer->Send();
				}
				catch (Exception $e)
				{
					// throw new Exception(Text::_('Error sending email: ' . $e->getMessage()), 403);
				}
            }
            
            // store data in db
            if ($this->save_logs_to_db) {
                // insert data
                $db = Factory::getDbo();
                $query = $db->getQuery(true);
                $columns = array('ip_address', 'name', 'username', 'password', 'datetime', 'country', 'browser', 'operating_system', 'status', 'where');
                $values = array($db->quote($ip_address), $db->quote($name), $db->quote($username), $db->quote($password), $db->quote($datetime), $db->quote($country), $db->quote($browser), $db->quote($operating_system), $db->quote($status), $db->quote($where));
                $query
					->insert($db->quoteName('#__failed_login_attempts_logs'))
					->columns($db->quoteName($columns))
					->values(implode(',', $values));
                $db->setQuery($query);
                $db->execute();
            }
        }							
	}
	
	/**
	 * This method should handle any authentication and report back to the subject
	 *
	 * @param   array   $credentials  Array holding the user credentials
	 * @param   array   $options      Array of extra options
	 * @param   object  &$response    Authentication response object
	 *
	 * @return  void
	 *
	 * @since   1.5
	 */
	public function onUserAuthenticate($credentials, $options, &$response)
	{
		Log::addLogger(array('text_file' => 'plg_authentication_failedloginattempts.log.php'), Log::ALL, array('plg_authentication_failedloginattempts'));

		$db = Factory::getDbo();
		$app = Factory::getApplication();

		$response->type = 'Joomla';
		
		/**
		 * JOOMLA! COOKIE AUTHENTICATION (remember_me)
		 */
		// Get cookie
		$cookieName  = 'joomla_remember_me_' . UserHelper::getShortHashedUserAgent();
		$cookieValue = $app->input->cookie->get($cookieName);

        if ($cookieValue) {
            $cookieArray = explode('.', $cookieValue);

            // Check for valid cookie value
            if (count($cookieArray) !== 2) {
                // Destroy the cookie in the browser.
                $app->input->cookie->set($cookieName, '', 1, $app->get('cookie_path', '/'), $app->get('cookie_domain', ''));
                Log::add('Invalid cookie detected.', Log::WARNING, 'plg_authentication_failedloginattempts');

                return false;
            }

            $response->type = 'Cookie';

            // Filter series since we're going to use it in the query
            $filter = new JFilterInput;
            $series = $filter->clean($cookieArray[1], 'ALNUM');

            // Find the matching record if it exists.
            $query = $db->getQuery(true)
                ->select($db->quoteName(array('user_id', 'token', 'series', 'time')))
                ->from($db->quoteName('#__user_keys'))
                ->where($db->quoteName('series') . ' = ' . $db->quote($series))
                ->where($db->quoteName('uastring') . ' = ' . $db->quote($cookieName))
                ->order($db->quoteName('time') . ' DESC');

            try {
                $results = $db->setQuery($query)->loadObjectList();

            } catch (RuntimeException $e) {
                $response->status = Authentication::STATUS_FAILURE;
                return false;
            }

            // Make sure there really is a user with this name and get the data for the session.
            $query = $db->getQuery(true)
                ->select($db->quoteName(array('id', 'username', 'password')))
                ->from($db->quoteName('#__users'))
                ->where($db->quoteName('username') . ' = ' . $db->quote($results[0]->user_id))
                ->where($db->quoteName('requireReset') . ' = 0');

            try {
                $result = $db->setQuery($query)->loadObject();

            } catch (RuntimeException $e) {
                $response->status = Authentication::STATUS_FAILURE;
                return false;
            }

            if ($result) {
                // Bring this in line with the rest of the system
                $user = JUser::getInstance($result->id);

                // Set response data.
                $response->username = $result->username;
                $response->email    = $user->email;
                $response->fullname = $user->name;
                $response->password = $result->password;
                $response->language = $user->getParam('language');

                // Set response status.
                $response->status        = Authentication::STATUS_SUCCESS;
                $response->error_message = '';

				$credentials = [
					'username' => $response->username,
					'password' => $response->username
				];

				// succesfully login
				if ($this->successful_login_attempts == 1) {
					$this->storeData($credentials, 'PLG_FLA_SUCCESSFULLY_LOGIN');
					return;
				}

            } else {
                $response->status        = Authentication::STATUS_FAILURE;
                $response->error_message = Text::_('JGLOBAL_AUTH_NO_USER');

				$credentials = [
					'username' => '',
					'password' => ''
				];

				$this->storeData($credentials, 'JGLOBAL_AUTH_NO_USER');
				return;
			}
        }

		/**
		 * JOOMLA! AUTHENTICATION
		 */
		
		// Joomla does not like blank passwords
		if (isset($credentials['password']) && empty($credentials['password']))
		{
			$response->status        = Authentication::STATUS_FAILURE;
			$response->error_message = Text::_('JGLOBAL_AUTH_EMPTY_PASS_NOT_ALLOWED');

			$this->storeData($credentials, 'JGLOBAL_AUTH_EMPTY_PASS_NOT_ALLOWED');

			return;
		}

		// Get a database object
		$db    = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('id, password')
			->from('#__users')
			->where('username=' . $db->quote($credentials['username']));

		$db->setQuery($query);
		$result = $db->loadObject();

		if ($result)
		{
			$match = UserHelper::verifyPassword($credentials['password'], $result->password, $result->id);

			if ($match === true)
			{
				// Bring this in line with the rest of the system
				$user               = JUser::getInstance($result->id);
				$response->email    = $user->email;
				$response->fullname = $user->name;

				if (Factory::getApplication()->isClient('administrator'))
				{
					$response->language = $user->getParam('admin_language');
				}
				else
				{
					$response->language = $user->getParam('language');
				}

				$response->status        = Authentication::STATUS_SUCCESS;
				$response->error_message = '';

				// If the user is blocked, redirect with an error
				if ($user->block == 1)
				{
					$this->storeData($credentials, 'JERROR_NOLOGIN_BLOCKED');
				}
				else
				{
					// succesfully login
                    if ($this->successful_login_attempts == 1) {
                        $this->storeData($credentials, 'PLG_FLA_SUCCESSFULLY_LOGIN');
                    }
				}
			}
			else
			{
				// Invalid password
				$response->status        = Authentication::STATUS_FAILURE;
				$response->error_message = Text::_('JGLOBAL_AUTH_INVALID_PASS');

				// invalid pass
				$this->storeData($credentials, 'JGLOBAL_AUTH_INVALID_PASS');
			}
		}
		else
		{
			// Let's hash the entered password even if we don't have a matching user for some extra response time
			// By doing so, we mitigate side channel user enumeration attacks
			UserHelper::hashPassword($credentials['password']);

			// Invalid user
			$response->status        = Authentication::STATUS_FAILURE;
			$response->error_message = Text::_('JGLOBAL_AUTH_NO_USER');

			// no authorised user
			$this->storeData($credentials, 'JGLOBAL_AUTH_NO_USER');
		}

		// Check the two factor authentication
		if ($response->status === Authentication::STATUS_SUCCESS)
		{
			$methods = AuthenticationHelper::getTwoFactorMethods();

			if (count($methods) <= 1)
			{
				// No two factor authentication method is enabled
				return;
			}

			JModelLegacy::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_users/models', 'UsersModel');

			/** @var UsersModelUser $model */
			$model = JModelLegacy::getInstance('User', 'UsersModel', array('ignore_request' => true));

			// Load the user's OTP (one time password, a.k.a. two factor auth) configuration
			if (!array_key_exists('otp_config', $options))
			{
				$otpConfig             = $model->getOtpConfig($result->id);
				$options['otp_config'] = $otpConfig;
			}
			else
			{
				$otpConfig = $options['otp_config'];
			}

			// Check if the user has enabled two factor authentication
			if (empty($otpConfig->method) || ($otpConfig->method === 'none'))
			{
				// Warn the user if they are using a secret code but they have not
				// enabled two factor auth in their account.
				if (!empty($credentials['secretkey']))
				{
					try
					{
						$app = Factory::getApplication();

						$this->loadLanguage();

						$app->enqueueMessage(Text::_('PLG_AUTH_JOOMLA_ERR_SECRET_CODE_WITHOUT_TFA'), 'warning');
					}
					catch (Exception $exc)
					{
						// This happens when we are in CLI mode. In this case
						// no warning is issued
						return;
					}
				}

				return;
			}

			// Try to validate the OTP
			FOFPlatform::getInstance()->importPlugin('twofactorauth');

			$otpAuthReplies = FOFPlatform::getInstance()->runPlugins('onUserTwofactorAuthenticate', array($credentials, $options));

			$check = false;

			/*
			 * This looks like noob code but DO NOT TOUCH IT and do not convert
			 * to in_array(). During testing in_array() inexplicably returned
			 * null when the OTEP begins with a zero! o_O
			 */
			if (!empty($otpAuthReplies))
			{
				foreach ($otpAuthReplies as $authReply)
				{
					$check = $check || $authReply;
				}
			}

			// Fall back to one time emergency passwords
			if (!$check)
			{
				// Did the user use an OTEP instead?
				if (empty($otpConfig->otep))
				{
					if (empty($otpConfig->method) || ($otpConfig->method === 'none'))
					{
						// Two factor authentication is not enabled on this account.
						// Any string is assumed to be a valid OTEP.

						return;
					}
					else
					{
						/*
						 * Two factor authentication enabled and no OTEPs defined. The
						 * user has used them all up. Therefore anything they enter is
						 * an invalid OTEP.
						 */
						$response->status        = Authentication::STATUS_FAILURE;
						$response->error_message = Text::_('JGLOBAL_AUTH_INVALID_SECRETKEY');

						return;
					}
				}

				// Clean up the OTEP (remove dashes, spaces and other funny stuff
				// our beloved users may have unwittingly stuffed in it)
				$otep  = $credentials['secretkey'];
				$otep  = filter_var($otep, FILTER_SANITIZE_NUMBER_INT);
				$otep  = str_replace('-', '', $otep);
				$check = false;

				// Did we find a valid OTEP?
				if (in_array($otep, $otpConfig->otep))
				{
					// Remove the OTEP from the array
					$otpConfig->otep = array_diff($otpConfig->otep, array($otep));

					$model->setOtpConfig($result->id, $otpConfig);

					// Return true; the OTEP was a valid one
					$check = true;
				}
			}

			if (!$check)
			{
				$response->status        = Authentication::STATUS_FAILURE;
				$response->error_message = Text::_('JGLOBAL_AUTH_INVALID_SECRETKEY');
			}
		}
	}

	function loginCheck($credentials)
	{
		// Get a database object
		$db		= Factory::getDbo();
		$query	= $db->getQuery(true);

		$query->select('id, password');
		$query->from('#__users');
		$query->where('username=' . $db->quote($credentials['username']));

		$db->setQuery($query);
		$result = $db->loadObject();
		
		return $result;
	}
	
	function verifyPass($credentials)
	{
		$result = $this->loginCheck($credentials);
		return UserHelper::verifyPassword($credentials['password'], $result->password, $result->id);
	}
}