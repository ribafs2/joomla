<?php
/* ======================================================
 # Failed Login Attempts for Joomla! - v2.5.5 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v3.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://www.web357.com/product/failed-login-attempts-joomla-plugin
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */
// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\Helpers\Sidebar;
use Joomla\CMS\Toolbar\ToolbarHelper;

/**
 * View class for a list of Failedloginattempts.
 *
 * @since  1.6
 */
class FailedloginattemptsViewFailedloginattempts extends \Joomla\CMS\MVC\View\HtmlView
{
	protected $items;

	protected $pagination;

	protected $state;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$this->state = $this->get('State');
		$this->items = $this->get('Items');
		$this->pagination = $this->get('Pagination');
        $this->filterForm = $this->get('FilterForm');
        $this->activeFilters = $this->get('ActiveFilters');
		$this->link_to_pro = '<a href="https://www.web357.com/product/failed-login-attempts-joomla-plugin?utm_source=CLIENT&amp;utm_medium=CLIENT-FLA-ProLink-web357&amp;utm_content=CLIENT-FLA-ProLink&amp;utm_campaign=FLA_radiofelement_free_vs_pro" target="_blank">PRO</a>';

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors));
		}

		FailedloginattemptsHelper::addSubmenu('failedloginattempts');

		$this->addToolbar();

		$this->sidebar = '';
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return void
	 *
	 * @since    1.6
	 */
	protected function addToolbar()
	{
		$state = $this->get('State');
		$canDo = FailedloginattemptsHelper::getActions();

		ToolbarHelper::title(Text::_('COM_FAILEDLOGINATTEMPTS_TITLE_FAILEDLOGINATTEMPTS'), 'lock.png');

		// Check if the form exists before showing the add/edit buttons
		$formPath = JPATH_COMPONENT_ADMINISTRATOR . '/views/failedloginattempt';

		if ($canDo->get('core.delete'))
		{
			if (isset($this->items[0]))
			{
				// If this component does not use state then show a direct delete button as we can not trash
				ToolbarHelper::deleteList('', 'failedloginattempts.delete', 'JTOOLBAR_DELETE');
				ToolbarHelper::custom('failedloginattempts.deleteAllLogs', 'purge.png', 'purge_f2.png', 'COM_FAILEDLOGINATTEMPTS_DELETE_ALL', false);
			}
		}

		if ($canDo->get('core.admin'))
		{
			ToolbarHelper::preferences('com_failedloginattempts');
		}

		// Set sidebar action
		if (version_compare(JVERSION, '5.0', '>=')) {
			Sidebar::setAction('index.php?option=com_failedloginattempts&view=failedloginattempts');
		}
		else
		{
			JHtmlSidebar::setAction('index.php?option=com_failedloginattempts&view=failedloginattempts');
		}
	}

	/**
	 * Method to order fields 
	 *
	 * @return void 
	 */
	protected function getSortFields()
	{
		return array(
			'a.`id`' => Text::_('JGRID_HEADING_ID'),
			'a.`ip_address`' => Text::_('COM_FAILEDLOGINATTEMPTS_FAILEDLOGINATTEMPTS_IP_ADDRESS'),
			'a.`username`' => Text::_('COM_FAILEDLOGINATTEMPTS_FAILEDLOGINATTEMPTS_USERNAME'),
			'a.`password`' => Text::_('COM_FAILEDLOGINATTEMPTS_FAILEDLOGINATTEMPTS_PASSWORD'),
			'a.`datetime`' => Text::_('COM_FAILEDLOGINATTEMPTS_FAILEDLOGINATTEMPTS_DATETIME'),
			'a.`country`' => Text::_('COM_FAILEDLOGINATTEMPTS_FAILEDLOGINATTEMPTS_COUNTRY'),
			'a.`browser`' => Text::_('COM_FAILEDLOGINATTEMPTS_FAILEDLOGINATTEMPTS_BROWSER'),
			'a.`operating_system`' => Text::_('COM_FAILEDLOGINATTEMPTS_FAILEDLOGINATTEMPTS_OPERATING_SYSTEM'),
			'a.`status`' => Text::_('COM_FAILEDLOGINATTEMPTS_FAILEDLOGINATTEMPTS_STATUS'),
			'a.`where`' => Text::_('COM_FAILEDLOGINATTEMPTS_FAILEDLOGINATTEMPTS_WHERE'),
		);
	}

    /**
     * Check if state is set
     *
     * @param   mixed  $state  State
     *
     * @return bool
     */
    public function getState($state)
    {
        return isset($this->state->{$state}) ? $this->state->{$state} : false;
    }
}
