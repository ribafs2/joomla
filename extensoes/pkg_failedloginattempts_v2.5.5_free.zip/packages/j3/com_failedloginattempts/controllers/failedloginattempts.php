<?php
/* ======================================================
 # Failed Login Attempts for Joomla! - v2.5.5 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v3.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://www.web357.com/product/failed-login-attempts-joomla-plugin
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */
// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.controlleradmin');

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

/**
 * Failedloginattempts list controller class.
 *
 * @since  1.6
 */
class FailedloginattemptsControllerFailedloginattempts extends \Joomla\CMS\MVC\Controller\AdminController
{
	/**
	 * Proxy for getModel.
	 *
	 * @param   string  $name    Optional. Model name
	 * @param   string  $prefix  Optional. Class prefix
	 * @param   array   $config  Optional. Configuration array for model
	 *
	 * @return  object	The Model
	 *
	 * @since    1.6
	 */
	public function getModel($name = 'failedloginattempt', $prefix = 'FailedloginattemptsModel', $config = array())
	{
		$model = parent::getModel($name, $prefix, array('ignore_request' => true));

		return $model;
	}

	public function deleteAllLogs()
	{	
		$view = Factory::getApplication()->input->get('view', 'failedloginattempts', 'STRING');

		// Delete all logs
		$db = Factory::getDBO();
		$query = $db->getQuery(true);
		$query->delete($db->quoteName('#__failed_login_attempts_logs'));
		$db->setQuery($query);
		$db->execute();
 
		// Redirect to the list screen.
		$this->setRedirect(JRoute::_('index.php?option=com_failedloginattempts&view='.$view, false), Text::_('COM_FAILEDLOGINATTEMPTS_ALL_LOGS_DELETED_SUCCESSFULLY'), 'message');
	}
}