<?php
/* ======================================================
 # Failed Login Attempts for Joomla! - v2.5.5 (free version)
 # -------------------------------------------------------
 # For Joomla! CMS (v3.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2023 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Demo: https://www.web357.com/product/failed-login-attempts-joomla-plugin
 # Support: support@web357.com
 # Last modified: Thursday 11 January 2024, 12:48:11 AM
 ========================================================= */
// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\Helpers\Sidebar;
use Joomla\CMS\Object\CMSObject;

/**
 * Failedloginattempts helper.
 *
 * @since  1.6
 */
class FailedloginattemptsHelper
{
	/**
	 * Configure the Linkbar.
	 *
	 * @param   string  $vName  string
	 *
	 * @return void
	 */
	public static function addSubmenu($vName = '')
	{
		// Set sidebar action
		if (version_compare(JVERSION, '5.0', '>=')) {
			Sidebar::addEntry(Text::_('COM_FAILEDLOGINATTEMPTS_TITLE_FAILEDLOGINATTEMPTS'), 'index.php?option=com_failedloginattempts&view=failedloginattempts', $vName == 'failedloginattempts');
			Sidebar::addEntry(Text::_('COM_FAILEDLOGINATTEMPTS_CONFIGURATION_SIDEBAR_LABEL'), 'index.php?option=com_config&view=component&component=com_failedloginattempts', $vName == 'settingscore');
		}
		else
		{
			JHtmlSidebar::addEntry(Text::_('COM_FAILEDLOGINATTEMPTS_TITLE_FAILEDLOGINATTEMPTS'), 'index.php?option=com_failedloginattempts&view=failedloginattempts', $vName == 'failedloginattempts');
			JHtmlSidebar::addEntry(Text::_('COM_FAILEDLOGINATTEMPTS_CONFIGURATION_SIDEBAR_LABEL'), 'index.php?option=com_config&view=component&component=com_failedloginattempts', $vName == 'settingscore');
		}
	}

	/**
	 * Gets the files attached to an item
	 *
	 * @param   int     $pk     The item's id
	 *
	 * @param   string  $table  The table's name
	 *
	 * @param   string  $field  The field's name
	 *
	 * @return  array  The files
	 */
	public static function getFiles($pk, $table, $field)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select($field)
			->from($table)
			->where('id = ' . (int) $pk);

		$db->setQuery($query);

		return explode(',', $db->loadResult());
	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @return    JObject
	 *
	 * @since    1.6
	 */
	public static function getActions()
	{
		$user   = Factory::getUser();
		$result = new CMSObject();

		$assetName = 'com_failedloginattempts';

		$actions = array(
			'core.admin', 'core.manage', 'core.delete'
		);

		foreach ($actions as $action)
		{
			$result->set($action, $user->authorise($action, $assetName));
		}

		return $result;
	}
}

