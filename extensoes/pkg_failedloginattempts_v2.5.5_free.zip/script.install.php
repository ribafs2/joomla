<?php
/* ======================================================
 # Web357 Installer for Joomla! - v1.0.0
 # -------------------------------------------------------
 # For Joomla! CMS (v3.x and v4.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2021 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Support: support@web357.com
 ========================================================= */

defined('_JEXEC') or die;

if ( ! class_exists('Web357Installer'))
{
	require_once __DIR__ . '/script.helper.php';
}

class PlgSystemWeb357InstallerFailedloginattemptsInstallerScript extends Web357Installer
{
	var $dir           = null;
	var $packages_dir  = null;
	var $installerName = 'web357installerfailedloginattempts';
   	var $jversion; 
    var $jversion_txt;
	
	public function __construct()
	{
		$this->dir = __DIR__;
		$this->jversion = (int) JVERSION;
		$this->jversion_txt = substr(JVERSION, 0, 3);  // returns "3.9", instead of 3.9.28

		if ($this->jversion >= 4)
		{
			$this->packages_dir = $this->dir . '/packages/j45';
		}
		else
		{
			$this->packages_dir = $this->dir . '/packages/j' . $this->jversion;
		}
	}
}