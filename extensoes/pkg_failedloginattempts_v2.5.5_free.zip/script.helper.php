<?php
/* ======================================================
 # Web357 Installer for Joomla! - v1.0.0
 # -------------------------------------------------------
 # For Joomla! CMS (v3.x and v4.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2021 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Support: support@web357.com
 ========================================================= */

defined('_JEXEC') or die;
use Joomla\CMS\Version;
use Joomla\CMS\Factory;
use Joomla\Filesystem\File;
use Joomla\Filesystem\Folder;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Installer\Installer;
use Joomla\CMS\Installer\Adapter\LibraryAdapter;

// Get Joomla! version
$jversion = new Version();
$short_version = explode('.', $jversion->getShortVersion()); // 3.8.10
$mini_version = $short_version[0].'.'.$short_version[1]; // 3.8

class Web357Installer
{
	private $min_joomla_version = [3 => '3.9.0', 4 => '3.9999', 5 => '4.9999'];
	private $min_php_version 	= [3 => '5.6', 4 => '7.2', 5 => '8.1'];

	public function preflight($route, $adapter)
	{
		// To prevent installer from running twice if installing multiple extensions
		if ( ! file_exists($this->dir . '/' . $this->installerName . '.xml'))
		{
			return true;
		}

		Factory::getLanguage()->load('plg_system_web357installer', $this->dir);

		if ( ! $this->passMinimumJoomlaVersion())
		{
			$this->uninstallInstaller();

			return false;
		}

		if ( ! $this->passMinimumPHPVersion())
		{
			$this->uninstallInstaller();

			return false;
		}

		// To prevent XML not found error
		$this->createExtensionRoot();

		return true;
	}

	public function postflight($route, $adapter)
	{
		if (!in_array($route, array('install', 'update')))
		{
			return true;
		}

		// To prevent installer from running twice if installing multiple extensions
		if ( ! file_exists($this->dir . '/' . $this->installerName . '.xml'))
		{
			return true;
		}

		// First install the Web357 Framework
		if ( ! $this->installWeb357Framework())
		{
			// Uninstall this installer
			$this->uninstallInstaller();

			return false;
		}

		// Then install the rest of the packages
		if ( ! $this->installPackages())
		{
			// Uninstall this installer
			$this->uninstallInstaller();

			return false;
		}

		// Uninstall this installer
		$this->uninstallInstaller();

		return true;
	}

	private function createExtensionRoot()
	{
		jimport('joomla.filesystem.folder');
		jimport('joomla.filesystem.file');

		$destination = JPATH_PLUGINS . '/system/' . $this->installerName;

		Folder::create($destination);

		File::copy(
			$this->dir . '/' . $this->installerName . '.xml',
			$destination . '/' . $this->installerName . '.xml'
		);
	}

	// Check if Joomla version passes minimum requirement
	private function passMinimumJoomlaVersion()
	{		

		if ( ! file_exists($this->packages_dir))
		{
			Factory::getApplication()->enqueueMessage(
				Text::sprintf(
					'W357_NOT_COMPATIBLE_JOOMLA',
					$this->jversion_txt
				),
				'error'
			);

			return false;
		}

		if (version_compare(JVERSION, $this->min_joomla_version[$this->jversion], '<'))
		{
			Factory::getApplication()->enqueueMessage(
				Text::sprintf(
					'W357_NOT_COMPATIBLE_UPDATE',
					JVERSION,
					$this->min_joomla_version[$this->jversion]
				),
				'error'
			);

			return false;
		}

		return true;
	}

	// Check if PHP version passes minimum requirement
	private function passMinimumPHPVersion()
	{
		if (version_compare(PHP_VERSION, $this->min_php_version[$this->jversion], 'lt'))
		{
			Factory::getApplication()->enqueueMessage(
				Text::sprintf(
					'W357_NOT_COMPATIBLE_PHP',
					'<strong>' . PHP_VERSION . '</strong>',
					'<strong>' . $this->min_php_version[$this->jversion] . '</strong>'
				),
				'error'
			);

			return false;
		}

		return true;
	}

	private function installPackages()
	{
		$packages = Folder::folders($this->packages_dir);

		$packages = array_diff($packages, array('plg_system_web357framework'));

		foreach ($packages as $package)
		{
			if ( ! $this->installPackage($package))
			{
				return false;
			}
		}

		return true;
	}

	private function installPackage($package)
	{
		$tmpInstaller = new W357Installer;

		$installed = $tmpInstaller->install($this->packages_dir . '/' . $package);

		if ( ! empty($tmpInstaller->manifestClass->softbreak))
		{
			return true;
		}

		return $installed;
	}

	private function installWeb357Framework()
	{
		if (!$this->installPackage('plg_system_web357framework'))
		{
			Factory::getApplication()->enqueueMessage(Text::_('W357_ERROR_INSTALLATION_FRAMEWORK_FAILED'), 'error');

			return false;
		}

		Factory::getCache()->clean('_system');

		return true;
	}

	private function uninstallInstaller()
	{
		if ( ! is_dir(JPATH_PLUGINS . '/system/' . $this->installerName))
		{
			return;
		}

		$this->delete(array(
			JPATH_PLUGINS . '/system/' . $this->installerName . '/language',
			JPATH_PLUGINS . '/system/' . $this->installerName,
		));

		$db = Factory::getDbo();

		$query = $db->getQuery(true)
			->delete('#__extensions')
			->where($db->quoteName('element') . ' = ' . $db->quote($this->installerName))
			->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
			->where($db->quoteName('type') . ' = ' . $db->quote('plugin'));
		$db->setQuery($query);
		$db->execute();

		Factory::getCache()->clean('_system');
	}

	public function delete($files = array())
	{
		foreach ($files as $file)
		{
			if (is_dir($file))
			{
				Folder::delete($file);
			}

			if (is_file($file))
			{
				File::delete($file);
			}
		}
	}
}

/*
 * Override core Library Installer to prevent it from uninstalling the library before upgrade
 * We need the files to check for the version to decide whether to install or not.
 */

 class W357Installer extends Installer
{
	public function getAdapter($name, $options = array())
	{
		if ($name == 'library')
		{
			return new W357InstallerAdapterLibrary($this, $this->getDbo(), $options);
		}

		$adapter = $this->loadAdapter($name, $options);

		if ( ! array_key_exists($name, $this->_adapters))
		{
			if ( ! $this->setAdapter($name, $adapter))
			{
				return false;
			}
		}

		return $adapter;
	}
} 

 if (version_compare($mini_version, "2.5", ">"))
{
	class W357InstallerAdapterLibrary extends LibraryAdapter
	{
		protected function checkExtensionInFilesystem()
		{
			if ( ! $this->currentExtensionId)
			{
				return;
			}

			// Already installed, can we upgrade?
			if ( ! $this->parent->isOverwrite() && ! $this->parent->isUpgrade())
			{
				// Abort the install, no upgrade possible
				throw new RuntimeException(Text::_('JLIB_INSTALLER_ABORT_LIB_INSTALL_ALREADY_INSTALLED'));
			}

			// From this point we'll consider this an update
			$this->setRoute('update');
		}

		protected function storeExtension()
		{
			$db    = $this->parent->getDbo();
			$query = $db->getQuery(true)
				->delete($db->quoteName('#__extensions'))
				->where($db->quoteName('type') . ' = ' . $db->quote('library'))
				->where($db->quoteName('element') . ' = ' . $db->quote($this->element));
			$db->setQuery($query);

			$db->execute();

			parent::storeExtension();

			Factory::getCache()->clean('_system');
		}
	}
}