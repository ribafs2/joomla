<?php
/* ======================================================
 # Web357 Installer for Joomla! - v1.0.0
 # -------------------------------------------------------
 # For Joomla! CMS (v3.x and v4.x)
 # Author: Web357 (Yiannis Christodoulou)
 # Copyright (©) 2014-2021 Web357. All rights reserved.
 # License: GNU/GPLv3, http://www.gnu.org/licenses/gpl-3.0.html
 # Website: https:/www.web357.com
 # Support: support@web357.com
 ========================================================= */

// Silence is Gold
defined('_JEXEC') or die;