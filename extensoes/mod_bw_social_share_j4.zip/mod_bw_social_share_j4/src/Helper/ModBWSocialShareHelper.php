<?php

/** 
 * Joomla.Module - NetzSinn Social Share
 * ------------------------------------------------------------------------
 * @package     mod_bw_social_share
 * @author      Netzsinn.de
 * @copyright   2023 netzsinn.de
 * @license     GNU/GPLv3 <http://www.gnu.org/licenses/gpl-3.0.de.html>
 * @link        https://netzsinn.de
 * ------------------------------------------------------------------------
 */

namespace NetzSinn\Module\ModBWSocialShare\Site\Helper;

// no direct access
defined('_JEXEC') or die('Restricted access');


use Joomla\CMS\Factory;
use Joomla\Registry\Registry;

class ModBWSocialShareHelper
{

	// public function urloptimize($string)
	// {
	// 	$string = str_replace(' ', '%20', $string);
	// 	return $string;
	// }
	// public function urlencode($string)
	// {
	// 	$string = urlencode($string);
	// 	$string = str_replace('|', '%7C', $string);
	// 	return $string;
	// }

	public function getIs_debug(Registry $params)
	{
		return $params->get('is_debug');
	}

	public function getTitle(Registry $params, $og_title = null, $document_title = null)
	{
		return $params->get('social_title') != null && strlen(trim($params->get('social_title'))) > 0 ? $params->get('social_title') : ($og_title != null ? $og_title : $document_title);
	}

	public function getDescription(Registry $params, $og_description = null, $description = null)
	{
		return $params->get('social_description') != null && strlen(trim($params->get('social_description'))) > 0 ? $params->get('social_description') : ($og_description != null ? $og_description : $description);
	}

	public function getAuthor(Registry $params, $server_name)
	{
		return $params->get('social_author') != null && strlen(trim($params->get('social_author'))) > 0 ? $params->get('social_author') : $server_name;
	}

	public function getPath(Registry $params, $og_url = null, $current_uri = null)
	{
		return $params->get('social_path') != null && strlen(trim($params->get('social_path'))) > 0 ? $params->get('social_path') : ($og_url != null ? $og_url : $current_uri);
	}

	public function getImg(Registry $params, $og_img = null)
	{
		return $params->get('social_img') != null && strlen(trim($params->get('social_img'))) > 0 ? $params->get('social_img') : ($og_img  != null ? $og_img  : '');
	}


	public function getBox_title(Registry $params)
	{
		return $params->get('box_title');
	}

	public function getIs_google_analytcis(Registry $params)
	{
		return $params->get('is_google_analytcis');
	}

	public function getIs_just_icons(Registry $params)
	{
		return $params->get('is_just_icons');
	}

	public function getIs_hide_box_title(Registry $params)
	{
		return $params->get('is_hide_box_title');
	}

	public function getOg_title($open_graph)
	{
		return (array_key_exists('og:title', $open_graph) && strlen(trim($open_graph['og:title'])) > 0) ? $open_graph['og:title'] : null;
	}

	public function getOg_description($open_graph)
	{
		return array_key_exists('og:description', $open_graph) && strlen(trim($open_graph['og:description'])) > 0 ? $open_graph['og:description'] : null;
	}

	public function getOg_url($open_graph)
	{
		return array_key_exists('og:url', $open_graph) && strlen(trim($open_graph['og:url'])) > 0 ? $open_graph['og:url'] : null;
	}

	public function getOg_img($open_graph)
	{
		return array_key_exists('og:image', $open_graph) && strlen(trim($open_graph['og:image'])) > 0 ? $open_graph['og:image'] : null;
	}




	public function getIs_facebook(Registry $params)
	{
		return $params->get('is_facebook');
	}
	public function getFacebook_button(Registry $params)
	{
		return $params->get('facebook_button');
	}
	public function getIs_twitter(Registry $params)
	{
		return $params->get('is_twitter');
	}
	public function getTwitter_button(Registry $params)
	{
		return $params->get('twitter_button');
	}
	public function getIs_pinterest(Registry $params)
	{
		return $params->get('is_pinterest');
	}
	public function getPinterest_button(Registry $params)
	{
		return $params->get('pinterest_button');
	}
	public function getIs_email(Registry $params)
	{
		return $params->get('is_email');
	}
	public function getEmail_button(Registry $params)
	{
		return $params->get('email_button');
	}
	public function getIs_instagram(Registry $params)
	{
		return $params->get('is_instagram');
	}
	public function getInstagram_button(Registry $params)
	{
		return $params->get('instagram_button');
	}
	public function getIs_tumblr(Registry $params)
	{
		return $params->get('is_tumblr');
	}
	public function getTumblr_button(Registry $params)
	{
		return $params->get('tumblr_button');
	}
	public function getIs_linkedin(Registry $params)
	{
		return $params->get('is_linkedin');
	}
	public function getLinkedin_button(Registry $params)
	{
		return $params->get('linkedin_button');
	}
	public function getIs_reddit(Registry $params)
	{
		return $params->get('is_reddit');
	}
	public function getReddit_button(Registry $params)
	{
		return $params->get('reddit_button');
	}
	public function getIs_vk(Registry $params)
	{
		return $params->get('is_vk');
	}
	public function getVk_button(Registry $params)
	{
		return $params->get('vk_button');
	}
	public function getIs_hackernews(Registry $params)
	{
		return $params->get('is_hackernews');
	}
	public function getHackernews_button(Registry $params)
	{
		return $params->get('hackernews_button');
	}
	public function getIs_pocket(Registry $params)
	{
		return $params->get('is_pocket');
	}
	public function getPocket_button(Registry $params)
	{
		return $params->get('pocket_button');
	}

	public function getIs_youtube(Registry $params)
	{
		return $params->get('is_youtube');
	}
	public function getYoutube_button(Registry $params)
	{
		return $params->get('youtube_button');
	}

	public function getIs_print(Registry $params)
	{
		return $params->get('is_print');
	}
	public function getPrint_button(Registry $params)
	{
		return $params->get('print_button');
	}

	public function getIs_whatsapp(Registry $params)
	{
		return $params->get('is_whatsapp');
	}
	public function getWhatsapp_button(Registry $params)
	{
		return $params->get('whatsapp_button');
	}

	public function getIs_xing(Registry $params)
	{
		return $params->get('is_xing');
	}
	public function getXing_button(Registry $params)
	{
		return $params->get('xing_button');
	}

	public function getIs_telegram(Registry $params)
	{
		return $params->get('is_telegram');
	}
	public function getTelegram_button(Registry $params)
	{
		return $params->get('telegram_button');
	}
}
