<?php

/** 
 * Joomla.Module - NetzSinn Social Share
 * ------------------------------------------------------------------------
 * @package     mod_bw_social_share
 * @author      Netzsinn.de
 * @copyright   2023 netzsinn.de
 * @license     GNU/GPLv3 <http://www.gnu.org/licenses/gpl-3.0.de.html>
 * @link        https://netzsinn.de
 * ------------------------------------------------------------------------
 */

namespace NetzSinn\Module\ModBWSocialShare\Site\Dispatcher;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;
use Joomla\CMS\Uri\Uri;

use NetzSinn\Module\ModBWSocialShare\Site\Helper\ModBWSocialShareHelper;

/**
 * Der Dispatcher sammelt alle Variablen, um sie später im Layout 
 * tmpl/default.php zu verwenden. Hier ergänzen wir den Parameter.
 *
 * @since  4.0.0
 */
class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;

    /**
     * Returns the layout data.
     *
     * @return  array $data
     *
     */
    protected function getLayoutData()
    {
        $data = parent::getLayoutData();

        /** @var CMSApplicationInterface $app */
        $app      = $this->getApplication();
        $document = $app->getDocument();
        $session  = $app->getSession();

        #$moduleHelper = new ModBWSocialShareHelper();

        /** @var ModBWSocialShareHelper $moduleHelper */
        $moduleHelper = $this->getHelperFactory()->getHelper('ModBWSocialShareHelper');

        /**
         * if parameter is not set
         * first check if a respective open graph parameter is available,
         * if not get the document meta data.
         *
         * accepted key for the open graph array:
         * og:title, og:description, og:url, og:image  
         */
        $open_graph                      = $session->get('open_graph', null);
        $data['og_title']                = null;
        $data['og_description']          = null;
        $data['og_url']                  = null;
        $data['og_img']                  = null;
        if ($open_graph != null) {
            $data['og_title']            = $moduleHelper->getOg_title($open_graph);
            $data['og_description']      = $moduleHelper->getOg_description($open_graph);
            $data['og_url']              = $moduleHelper->getOg_url($open_graph);
            $data['og_img']              = $moduleHelper->getOg_img($open_graph);
        }

        $data['title']                   = $moduleHelper->getTitle($data['params'], $data['og_title'], $document->getTitle());
        $data['title_urlencoded']        = urlencode($data['title']);
        $data['description']             = $moduleHelper->getDescription($data['params'], $data['og_description'], $document->getDescription());
        $data['author']                  = $moduleHelper->getAuthor($data['params'], $_SERVER['SERVER_NAME']);
        $data['img']                     = $moduleHelper->getImg($data['params'], $data['og_img']);
        $data['path']                    = $moduleHelper->getPath($data['params'], $data['og_path'], URI::current());
        $data['box_title']               = $moduleHelper->getBox_title($data['params']);

        $data['is_google_analytcis']     = $moduleHelper->getIs_google_analytcis($data['params']);
        $data['is_just_icons']           = $moduleHelper->getIs_just_icons($data['params']);
        $data['is_hide_box_title']       = $moduleHelper->getIs_hide_box_title($data['params']);
        $data['is_debug']                = $moduleHelper->getIs_debug($data['params']);

        $data['is_facebook']             = $moduleHelper->getIs_facebook($data['params']);
        $data['facebook_button']         = $moduleHelper->getFacebook_button($data['params']);
        $data['is_twitter']              = $moduleHelper->getIs_twitter($data['params']);
        $data['twitter_button']          = $moduleHelper->getTwitter_button($data['params']);
        $data['is_pinterest']            = $moduleHelper->getIs_pinterest($data['params']);
        $data['pinterest_button']        = $moduleHelper->getPinterest_button($data['params']);
        $data['is_email']                = $moduleHelper->getIs_email($data['params']);
        $data['email_button']            = $moduleHelper->getEmail_button($data['params']);
        $data['is_instagram']            = $moduleHelper->getIs_instagram($data['params']);
        $data['instagram_button']        = $moduleHelper->getInstagram_button($data['params']);
        $data['is_tumblr']               = $moduleHelper->getIs_tumblr($data['params']);
        $data['tumblr_button']           = $moduleHelper->getTumblr_button($data['params']);
        $data['is_linkedin']             = $moduleHelper->getIs_linkedin($data['params']);
        $data['linkedin_button']         = $moduleHelper->getLinkedin_button($data['params']);
        $data['is_reddit']               = $moduleHelper->getIs_reddit($data['params']);
        $data['reddit_button']           = $moduleHelper->getReddit_button($data['params']);
        $data['is_vk']                   = $moduleHelper->getIs_vk($data['params']);
        $data['vk_button']               = $moduleHelper->getVk_button($data['params']);
        $data['is_hackernews']           = $moduleHelper->getIs_hackernews($data['params']);
        $data['hackernews_button']       = $moduleHelper->getHackernews_button($data['params']);
        $data['is_pocket']               = $moduleHelper->getIs_pocket($data['params']);
        $data['pocket_button']           = $moduleHelper->getPocket_button($data['params']);
        $data['is_youtube']              = $moduleHelper->getIs_youtube($data['params']);
        $data['youtube_button']          = $moduleHelper->getYoutube_button($data['params']);
        $data['is_print']                = $moduleHelper->getIs_print($data['params']);
        $data['print_button']            = $moduleHelper->getPrint_button($data['params']);
        $data['is_whatsapp']             = $moduleHelper->getIs_whatsapp($data['params']);
        $data['whatsapp_button']         = $moduleHelper->getWhatsapp_button($data['params']);
        $data['is_xing']                 = $moduleHelper->getIs_xing($data['params']);
        $data['xing_button']             = $moduleHelper->getXing_button($data['params']);
        $data['is_telegram']             = $moduleHelper->getIs_telegram($data['params']);
        $data['telegram_button']         = $moduleHelper->getTelegram_button($data['params']);


        return $data;
    }
}
