<?php

/** 
 * Joomla.Module - NetzSinn Social Share
 * ------------------------------------------------------------------------
 * @package     mod_bw_social_share
 * @author      Netzsinn.de
 * @copyright   2023 netzsinn.de
 * @license     GNU/GPLv3 <http://www.gnu.org/licenses/gpl-3.0.de.html>
 * @link        https://netzsinn.de
 * ------------------------------------------------------------------------
 */

defined('_JEXEC') or die;

use Joomla\CMS\Extension\Service\Provider\HelperFactory;
use Joomla\CMS\Extension\Service\Provider\Module;
use Joomla\CMS\Extension\Service\Provider\ModuleDispatcherFactory;
use Joomla\DI\Container;
use Joomla\CMS\WebAsset\WebAssetRegistry;
use Joomla\DI\ServiceProviderInterface;


/** 
 * Joomla.Module - NetzSinn Social Share
 * ------------------------------------------------------------------------
 * @package     mod_bw_social_share
 * @author      Netzsinn.de
 * @copyright   2023 netzsinn.de
 * @license     GNU/GPLv3 <http://www.gnu.org/licenses/gpl-3.0.de.html>
 * @link        https://netzsinn.de
 * ------------------------------------------------------------------------
 */

return new class() implements ServiceProviderInterface
{
    /**
     * Registers the service provider with a DI container.
     *
     * @param   Container  $container  The DI container.
     *
     * @return  void
     */
    public function register(Container $container)
    {
        $container->registerServiceProvider(new ModuleDispatcherFactory('\\NetzSinn\\Module\\ModBWSocialShare'));
        $container->registerServiceProvider(new HelperFactory('\\NetzSinn\\Module\\ModBWSocialShare\\Site\\Helper'));

        $container->registerServiceProvider(new Module());

        $wa = $container->get(WebAssetRegistry::class);
        $wa->addRegistryFile('media/mod_bw_social_share/joomla.asset.json');
    }
};
