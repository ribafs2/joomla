jQuery(function ($) {
  mod_bw_social_share_styles();
  $(window).resize(function () {
    mod_bw_social_share_styles();
  });
});

function mod_bw_social_share_styles() {
  if ($(".bw-social-share-buttons-small").length > 0) {
    $(".bw-social-share-buttons li").addClass("small");
    $(".bw-social-share-buttons li").css("width", "42px");

    $(".rrssb-buttons").removeClass("large-format");
    setTimeout(function () {
      $(".rrssb-buttons").removeClass("large-format");
      $(".bw-social-share-buttons li").addClass("small");
      $(".bw-social-share-buttons li").css("width", "42px");
    }, 500);
  } else if ($(".bw-social-share-buttons-large").length > 0) {
    if ($(window).width() > 320) {
      setTimeout(function () {
        $(".bw-social-share-buttons li").removeClass("small");
        $(".bw-social-share-buttons li").css("width", "calc(50%)");
      }, 500);
    } else {
      setTimeout(function () {
        $(".bw-social-share-buttons li").removeClass("small");
        $(".bw-social-share-buttons li").css("height", "100%");
        $(".bw-social-share-buttons li").css("width", "calc(100%)");
      }, 500);
    }
  }
}
