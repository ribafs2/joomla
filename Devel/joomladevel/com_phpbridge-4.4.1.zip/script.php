<?php
/**
 * @package     PHP-Bridge
 * @subpackage  com_phpbridge
 *
 * @copyright   Copyright (C) 2021 Henry Schorradt, Inc. All rights reserved.
 * @license     Licensed under the GPL v2&
 */

// No direct access to this file
defined('_JEXEC') or die;

use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Factory;

class com_phpbridgeInstallerScript
{
    const EXTENSION_NAME = 'com_phpbridge';

    public function preflight($type, $parent){
        //Delete cache folder if it exists
        $this->parent = $parent;
        $this->loadLanguage();

        $cache = JPATH_ROOT.'/cache/'.self::EXTENSION_NAME.'/';
        if(Folder::exists($cache)) Folder::delete($cache);
    }

    /**
     * Update cleans out any old rules.
     *
     * @param   \Joomla\Component\Installer\Administrator\Extension\InstallerComponent  $parent  Is the class calling this method.
     *
     * @return  bool|null  If this returns false, Joomla will abort the update and undo everything already done.
     */
    public function update($parent)
    {
        $this->loadLanguage();
    }

    public function getParam( $name ) {
        $db = Factory::getDbo();
        $db->setQuery('SELECT manifest_cache FROM #__extensions WHERE name = "'.self::EXTENSION_NAME.'"');
        $manifest = json_decode( $db->loadResult(), true );
        return $manifest[ $name ];
    }

    public function setParams($param_array) {
        if ( count($param_array) > 0 ) {
            $db = Factory::getDbo();
            $db->setQuery('SELECT params FROM #__extensions WHERE name = "'.self::EXTENSION_NAME.'"');
            $params = json_decode( $db->loadResult(), true );
            foreach ( $param_array as $name => $value ) {
                $params[ (string) $name ] = (string) $value;
            }
            $paramsString = json_encode( $params );
            $db->setQuery('UPDATE #__extensions SET params = ' . $db->quote( $paramsString ) . ' WHERE name = "'.self::EXTENSION_NAME.'"' );
            $db->execute();
        }
    }

    /**
     * Load language necessary during the installation
     *
     * @return void
     */
    public function loadLanguage()
    {
        $extension = self::EXTENSION_NAME;
        $app = Factory::getApplication();
        $jlang = $app->getLanguage();
        $path = $this->parent->getParent()->getPath('source') . '/administrator';
        $jlang->load($extension, $path, 'en-GB', true);
        $jlang->load($extension, $path, $jlang->getDefault(), true);
        $jlang->load($extension, $path, null, true);
        $jlang->load($extension . '.sys', $path, 'en-GB', true);
        $jlang->load($extension . '.sys', $path, $jlang->getDefault(), true);
        $jlang->load($extension . '.sys', $path, null, true);
    }


}
