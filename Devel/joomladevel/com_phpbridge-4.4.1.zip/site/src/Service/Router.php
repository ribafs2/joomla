<?php
/**
 * @package     PHP-Bridge
 * @subpackage  com_phpbridge
 *
 * @copyright   Copyright (C) 2021 Henry Schorradt, Inc. All rights reserved.
 * @license     Licensed under the GPL v2&
 */

namespace Schorradt\Component\PhpBridge\Site\Service;

\defined('_JEXEC') or die;

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Categories\CategoryFactoryInterface;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Component\Router\RouterView;
use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Factory;
use Joomla\CMS\Menu\AbstractMenu;
use Joomla\Database\DatabaseInterface;

/**
 * Routing class from com_privacy
 *
 * @since  3.9.0
 */
class Router extends RouterView
{

    /**
     * Content Component router constructor
     *
     * @param   SiteApplication           $app              The application object
     * @param   AbstractMenu              $menu             The menu object to work with
     * @param   CategoryFactoryInterface  $categoryFactory  The category object
     * @param   DatabaseInterface         $db               The database object
     */
    public function __construct($app = null, $menu = null)
    {
        $params = ComponentHelper::getParams('com_phpbridge');
        $this->noIDs = (bool) $params->get('sef_ids');

//        $categories = new RouterViewConfiguration('categories');
//        $categories->setKey('id');
//        $this->registerView($categories);
//
//        $category = new RouterViewConfiguration('category');
//        $category->setKey('id')->setParent($categories, 'parent_id')->setNestable();
//        $this->registerView($category);

        $phpbridge = new RouterViewConfiguration('phpbridge');
        $phpbridge->setName('Phpbridge');
        $this->registerView($phpbridge);

        parent::__construct($app, $menu);

        $this->attachRule(new MenuRules($this));
        $this->attachRule(new PhpbridgeMenuRules($this));
        $this->attachRule(new StandardRules($this));
        $this->attachRule(new NomenuRules($this));
    }

    public function getPhpbridgeSegment($id, $query)
    {
        return array();
    }

    public function getPhpbridgeId($segment, $query)
    {
        return false;
    }

    public function build(&$query)
    {
        if (isset($query['view']))
        {
            unset($query['view']);
        }

        return array();
    }

    /**
     * Parse the segments of a URL.
     *
     * @param   array  $segments  The segments of the URL to parse.
     *
     * @return  array  The URL attributes to be used by the application.
     *
     * @since   3.3
     */
    public function parse(&$segments)
    {
        return array('view' => 'phpbridge');
    }

    public function preprocess($query)
    {
        return $query;
    }

}

//function PhpbridgeBuildRoute(&$query)
//{
//
//    $app = Factory::getApplication();
//    $router = new Router($app, $app->getMenu());
//
//    return $router->build($query);
//}
//
//
//function PhpbridgeParseRoute($segments)
//{
//
//
//    $app = Factory::getApplication();
//    $router = new Router($app, $app->getMenu());
//
//    return $router->parse($segments);
//}