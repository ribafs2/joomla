<?php
/**
 * @package     PHP-Bridge
 * @subpackage  com_phpbridge
 *
 * @copyright   Copyright (C) 2021 Henry Schorradt, Inc. All rights reserved.
 * @license     Licensed under the GPL v2&
 */

namespace Schorradt\Component\PhpBridge\Site\Service;

defined('_JEXEC') or die();

use Joomla\CMS\Component\Router\Rules\MenuRules;

use Joomla\Registry\Registry;

class PhpbridgeMenuRules extends MenuRules
{
    public function preprocess(&$query)
    {

        parent::preprocess($query);

    }

    protected function buildLookup($language = '*')
    {
        parent::buildLookup($language);

    }

}