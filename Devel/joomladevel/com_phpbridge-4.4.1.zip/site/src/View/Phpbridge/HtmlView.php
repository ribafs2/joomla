<?php
/**
 * @package     PHP-Bridge
 * @subpackage  com_phpbridge
 *
 * @copyright   Copyright (C) 2021 Henry Schorradt, Inc. All rights reserved.
 * @license     Licensed under the GPL v2&
 */

namespace Schorradt\Component\PhpBridge\Site\View\Phpbridge;

// No direct access to this file
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\GenericDataException;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Uri\Uri;
use Joomla\Filesystem\File;
use Joomla\Filesystem\Path;

/**
 * HTML View class for the PhpBridge Component
 */
class HtmlView extends BaseHtmlView
{
    protected $html;

    /**
     * Execute and display a template script.
     *
     * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
     *
     * @return  mixed  A string if successful, otherwise an Error object.
     *
     * @throws \Exception
     * @since   1.6
     */
    public function display($tpl = null)
    {

        $this->app		= Factory::getApplication();
        $this->wa       = $this->getDocument()->getWebAssetManager();
        $this->params		= $this->app->getParams('com_phpbridge');

        // Assign data to the view
        $this->layout		= $this->getLayout();
        $this->print = $this->app->input->getBool('print');

        $global_css = htmlspecialchars($this->params->get('pb_css','') ?? '');
        $global_js = htmlspecialchars($this->params->get('pb_js','') ?? '');

        if(trim($global_css) != ''){
            $asset = 'templates/'.$this->app->getTemplate().'/css/' . trim($global_css);
            if(is_file(JPATH_ROOT.'/'.$asset)) {
                $path = Uri::root( true ).$asset;
                $this->wa->registerAndUseStyle('phpbridge_global_style', $path);
            }
            $asset = 'media/templates/site/'.$this->app->getTemplate().'/css/' . trim($global_css);
            if(is_file(JPATH_ROOT.'/'.$asset)) {
                $path = Uri::root( true ).$asset;
                $this->wa->registerAndUseStyle('phpbridge_global_style', $path);
            }
        }
        if(trim($global_js) != ''){
            $asset = 'templates/'.$this->app->getTemplate().'/js/' . trim($global_js);
            if(is_file(JPATH_ROOT.'/'.$asset)) {
                $path = Uri::root( true ).$asset;
                $this->wa->registerAndUseScript('phpbridge_global_script', $path);
            }
            $asset = 'media/templates/site/'.$this->app->getTemplate().'/js/' . trim($global_js);
            if(is_file(JPATH_ROOT.'/'.$asset)) {
                $path = Uri::root( true ).$asset;
                $this->wa->registerAndUseScript('phpbridge_script', $path);
            }
        }

        $menus   = $this->app->getMenu();
        $menu = $menus->getActive();

        if ($menu)
        {
            $this->params->def('page_heading', $this->params->get('page_title', $menu->title));
        }

        $title = $this->params->get('page_title', '');
        $css = $this->params->get('c_css', '');
        $js = $this->params->get('c_js', '');


        // Check for empty title and add site name if param is set
        if (empty($title))
        {
            $title = $this->app->get('sitename');
        }
        elseif ($this->app->get('sitename_pagetitles', 0) == 1)
        {
            $title = Text::sprintf('JPAGETITLE', $this->app->get('sitename'), $title);
        }
        elseif ($this->app->get('sitename_pagetitles', 0) == 2)
        {
            $title = Text::sprintf('JPAGETITLE', $title, $this->app->get('sitename'));
        }
        $this->getDocument()->setTitle($title);

        if ($this->params->get('menu-meta_description'))
        {
            $this->getDocument()->setDescription($this->params->get('menu-meta_description'));
        }

        if ($this->params->get('menu-meta_keywords'))
        {
            $this->getDocument()->setMetadata('keywords', $this->params->get('menu-meta_keywords'));
        }

        if ($this->params->get('robots'))
        {
            $this->getDocument()->setMetadata('robots', $this->params->get('robots'));
        }

        if ($this->print)
        {
            $this->getDocument()->setMetaData('robots', 'noindex, nofollow');
        }

        if(trim($css) != ''){
            $asset = 'templates/'.$this->app->getTemplate().'/css/' . trim($css);
            if(is_file(JPATH_ROOT.'/'.$asset)) {
                $path = Uri::root( true ).$asset;
                $this->wa->registerAndUseStyle('phpbridge_style', $path);
            }
            $asset = 'media/templates/site/'.$this->app->getTemplate().'/css/' . trim($css);
            if(is_file(JPATH_ROOT.'/'.$asset)) {
                $path = Uri::root( true ).$asset;
                $this->wa->registerAndUseStyle('phpbridge_style', $path);
            }
        }
        if(trim($js) != ''){
            $asset = 'templates/'.$this->app->getTemplate().'/js/' . trim($css);
            if(is_file(JPATH_ROOT.'/'.$asset)) {
                $path = Uri::root( true ).$asset;
                $this->wa->registerAndUseScript('phpbridge_script', $path);
            }
            $asset = 'media/templates/site/'.$this->app->getTemplate().'/js/' . trim($css);
            if(is_file(JPATH_ROOT.'/'.$asset)) {
                $path = Uri::root( true ).$asset;
                $this->wa->registerAndUseScript('phpbridge_script', $path);
            }
        }

        $this->pageclass_sfx = htmlspecialchars($this->params->get('pageclass_sfx') ?? '');

        $this->html        = $this->get('Html');

        // Check for errors.
        if (count($errors = $this->get('Errors')))
        {
            throw new GenericDataException(implode("\n", $errors), 500);
        }

        parent::display($tpl);
        return $this;
    }
}

