<?php
/**
 * @package     PHP-Bridge
 * @subpackage  com_phpbridge
 *
 * @copyright   Copyright (C) 2021 Henry Schorradt, Inc. All rights reserved.
 * @license     Licensed under the GPL v2&
 */

namespace Schorradt\Component\PhpBridge\Site\Library;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Factory;

defined('_JEXEC') or die('Restricted access');

class PhpBridgeModul {

	private	$run='';
	private	$mode='';
	private	$data=array();
	private $scriptfile = '';
		
	public function __construct($run='',$mode='',$data=''){
		$this->run = str_replace(array('..', '/'),'',addslashes(strip_tags($run)));
		$this->mode = addslashes(strip_tags($mode));
		$this->data = array_map('trim', explode(",",strip_tags($data)));
	}
		
	public function init($params){
		
		$path = $params->get('pb_path','templatephp');
		$app = Factory::getApplication();

        switch($path){
            case'rootphp':
                $tempfilename = JPATH_SITE.'/php/'.$this->run.'.php';
                break;
            default:
                $tempfilename = JPATH_SITE.'/templates/'.$app->getTemplate().'/php/'.$this->run.'.php';
                break;
        }

        if(!is_file($tempfilename) || !is_readable($tempfilename)){
            $app->enqueueMessage(Text::_('COM_PHPBRIDGE_MISSING_FILE'), 'error');
        } else {
            //SecureCheck
            $checkContent = file_get_contents($tempfilename);
            if (!preg_match('#_JEXEC#imU', $checkContent) && !preg_match('#defined#imU', $checkContent)) {
                $app->enqueueMessage(Text::_('COM_PHPBRIDGE_MISSING_SECURITY_CODE'), 'error');
                $tempfilename = '';
            }
        }
		
		if(is_file($tempfilename)){
			$this->scriptfile = $tempfilename;
		}else{
			$this->scriptfile = JPATH_SITE.'/components/com_phpbridge/src/Library/emptyscript.php';
		}
	}

	public function runScript(){
		$mode = $this->mode;
		$data = $this->data;
        $run = $this->run;
		$filename = addslashes(strip_tags($this->scriptfile));
        $app = Factory::getApplication();

		ob_start();
		if(is_file($filename))
		    try {
                include $filename;
            }catch(\Exception $e){
                $app->enqueueMessage(Text::_($e->getMessage()), 'error');
            }
		unset($filename);
		return ob_get_clean();
	}

}