<?php
/**
 * @package     PHP-Bridge
 * @subpackage  com_phpbridge
 *
 * @copyright   Copyright (C) 2021 Henry Schorradt, Inc. All rights reserved.
 * @license     Licensed under the GPL v2&
 */

defined('_JEXEC') or die('Restricted access');
?>
<p>PHP-Bridge - Henry Schorradt - www.henryschorradt.de</p>
<p>script is undefined!</p>
<?php

switch($mode){case'phpinfo':
	//echo phpinfo();
break;}//switch
