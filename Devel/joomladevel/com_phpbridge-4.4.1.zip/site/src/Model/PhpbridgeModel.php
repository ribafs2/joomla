<?php
/**
 * @package     PHP-Bridge
 * @subpackage  com_phpbridge
 *
 * @copyright   Copyright (C) 2021 Henry Schorradt, Inc. All rights reserved.
 * @license     Licensed under the GPL v2&
 */

namespace Schorradt\Component\PhpBridge\Site\Model;

// No direct access to this file
defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\BaseModel;
use Schorradt\Component\PhpBridge\Site\Library;

class PhpbridgeModel extends BaseModel
{
    /**
     * Model context string.
     * @var        string
     */
    protected $_context = 'com_phpbridge.phpview';

    /**
     * @var
     */
    protected $html;

    /**
     * @return string
     * @throws \Exception
     */
    public function getHtml()
    {
        $app = Factory::getApplication();
        $document = $app->getDocument();
        $input = $app->getInput();

        $params = ComponentHelper::getParams($input->get('option'));

        $c_run = $input->get('run','');

        //Security
        if(preg_match('/\.\./imU', $c_run)){
            $c_run = '';
        }

        $c_mode = $input->get('mode','');
        $c_data = $input->get('data','');
        $c_raw = $input->get('raw',0);

        $tempmodul = new Library\PhpBridgeModul($c_run, $c_mode, $c_data);
        $tempmodul->init($params);
        $this->html = $tempmodul->runScript();

        if($c_raw) {
            echo $this->html;
            die();
        }

        return $this->html;
    }

}
