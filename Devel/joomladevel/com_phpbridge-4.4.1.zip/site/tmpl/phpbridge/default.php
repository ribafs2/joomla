<?php
/**
 * @package     PHP-Bridge
 * @subpackage  com_phpbridge
 *
 * @copyright   Copyright (C) 2021 Henry Schorradt, Inc. All rights reserved.
 * @license     Licensed under the GPL v2&
 */

// No direct access to this file
defined('_JEXEC') or die();

?>
<div class="item-page<?php echo $this->pageclass_sfx?>">
<?php if ($this->params->get('show_page_heading', 1)) : ?>
	<h1>
	<?php echo $this->escape($this->params->get('page_heading')); ?>
	</h1>
<?php endif;
    echo $this->html;
?>
</div>