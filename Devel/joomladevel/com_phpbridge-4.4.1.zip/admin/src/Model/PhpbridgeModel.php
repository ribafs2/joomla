<?php
/**
 * @package     PHP-Bridge
 * @subpackage  com_phpbridge
 *
 * @copyright   Copyright (C) 2021 Henry Schorradt, Inc. All rights reserved.
 * @license     Licensed under the GPL v2&
 */

namespace Schorradt\Component\PhpBridge\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\BaseModel;


/**
 * Menu Item Model for Menus.
 *
 * @since  1.6
 */
class PhpbridgeModel extends BaseModel
{

}
