<?php
/**
 * @package     PHP-Bridge
 * @subpackage  com_phpbridge
 *
 * @copyright   Copyright (C) 2021 Henry Schorradt, Inc. All rights reserved.
 * @license     Licensed under the GPL v2&
 */

namespace Schorradt\Component\PhpBridge\Administrator\View\Phpbridge;

// No direct access to this file
use Joomla\CMS\Document\Document;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\GenericDataException;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Uri\Uri;
use Schorradt\Component\PhpBridge\Administrator\Model\PhpbridgeModel;

defined('_JEXEC') or die('Restricted access');


/**
 * PHPBridge View
 */
class HtmlView extends BaseHtmlView
{

    /**
     * @var  object
     */
    protected $item;

    /**
     * @var  \JObject
     */
    protected $state;

    /**
     * @var  \JObject
     */
    protected $canDo;

    /**
     *  view display method
     * @param null $tpl
     * @return void
     * @throws \Exception
     */
    public function display($tpl = null)
    {
        /** @var PhpbridgeModel $model */
        $model               = $this->getModel();
        $app		= Factory::getApplication();
        $document = $app->getDocument();

        $this->item    = $this->get('Item');
        $this->state   = $this->get('State');

        // Check for errors.
        if (count($errors = $model->getErrors()))
        {
            throw new GenericDataException(implode("\n", $errors), 500);
        }

        // Set the toolbar
        $this->addToolBar();

        // Set the document
        $this->setDocument($document);

        // Display the template
        parent::display($tpl);
    }

    /**
     * Setting the toolbar
     */
    public function addToolBar()
    {
        ToolbarHelper::title(Text::_('COM_PHPBRIDGE'), 'phpbridge');
        ToolbarHelper::preferences('com_phpbridge');
    }

    /**
     * Method to set up the document properties
     *
     * @param Document $document
     * @return void
     * @throws \Exception
     */
    public function setDocument(Document $document): void
    {
        $wa       = $document->getWebAssetManager();
        $document->setTitle(Text::_('COM_PHPBRIDGE_CONFIGURATION'));
        $path = Uri::root(true) . '/media/com_phpbridge/css/admin.styles.css';
        $wa->registerAndUseStyle($path);
    }
}
