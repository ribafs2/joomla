<?php


// No direct access
defined('_JEXEC') or die('Restricted access');

?>

 <div style="padding:20px;">
 <h2>Aixeena Easy Component by Aixeena Labs</h2>
 
 Se more info at <a href="http://www.aixeena.org">Aixeena</a>.
 
 </div>