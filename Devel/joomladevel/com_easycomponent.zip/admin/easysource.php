<?php
/**
 * @module		com_easysource
 * @script		easysource.php
 * @author-name Top Position
 * @copyright	Copyright (C) 2013 Top Position
 * @license		GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_easysource')) 
{
	return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}

if(!defined('DS')){
define('DS',DIRECTORY_SEPARATOR);
}
 
// require helper file
//JLoader::register('easysourceHelper', dirname(__FILE__) . DS . 'helpers' . DS . 'easysource.php');
 
// import joomla controller library
jimport('joomla.application.component.controller');
 
// Get an instance of the controller prefixed by easysource
$controller = JControllerLegacy::getInstance('easysource');
 
// Perform the Request task
$controller->execute(JRequest::getCmd('task'));
 
// Redirect if set by the controller
$controller->redirect();