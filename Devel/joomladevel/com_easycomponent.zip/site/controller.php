<?php
/**
 * Easy Family System - Easy Source
 * Component Version 1.0.0 - Joomla! Version 1.7
 * Author: Top Position
 * info@aixeena.org
 * http://aixeena.org
 * Copyright (c) 2011 Top Position. All Rights Reserved. 
 * License: GNU/GPL 2, http://www.gnu.org/licenses/gpl-2.0.html
 */
defined('_JEXEC') or die('Restricted access'); 
jimport( 'joomla.application.component.controller' );


class EasySourceController extends JControllerLegacy {
	
	public function display($cachable = false, $urlparams = false) {
		
		$app = JFactory::getApplication();
		$document = JFactory::getDocument();
		$jinput = $app->input;
		$itemId = $jinput->get('Itemid',0);
		
		$task =  JRequest::getString('task','');
		
		$vName = $this->input->get('view', 'default');
		$this->input->set('view', $vName);
		parent::display($cachable);
		return $this;
	}

}

?>