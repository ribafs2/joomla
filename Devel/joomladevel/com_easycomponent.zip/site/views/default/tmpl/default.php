<?php
/**
 * Aixeena Easy Component
 * Component Version 1.0.0 - Joomla! Version 1.7
 * Author: Top Position
 * info@aixeena.org
 * http://aixeena.org
 * Copyright (c) 2011 Top Position. All Rights Reserved. 
 * License: GNU/GPL 2, http://www.gnu.org/licenses/gpl-2.0.html
 */

defined('_JEXEC') or die('Restricted access'); 

$app	= JFactory::getApplication();
$params = $app->getParams();
$document = JFactory::getDocument();

$route = 		JURI::base(true).'/components/com_easysource/';
 
if($params->get('php_include1')) include 'components/com_easysource/includes/'.$params->get('php_include1');

if($params->get('js_include')) $document->addScript($route.'js/'.$params->get('js_include'));
	
if($params->get('css_include')) $document->addStyleSheet($route.'css/'.$params->get('css_include'));

//echo '<div style="padding:5px; text-align: right; font-size:12px;"><a href="'.$params->get( 'tplink').'" title="'.$params->get( 'tpalt').'">'.$params->get( 'tptext').'</a></div>';

echo '<div style="padding:5px; text-align: right; font-size:12px;">Desarrollado por la consultora <a href="http://t-position.com" title="en posicionamiento en google">en posicionamiento en google</a></div>';


?>