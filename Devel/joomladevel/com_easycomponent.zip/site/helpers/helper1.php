<?php
/**
 * Easy Family System - Easy Source
 * Component Version 1.0.0 - Joomla! Version 1.7
 * Author: Top Position
 * info@aixeena.org
 * http://aixeena.org
 * Copyright (c) 2011 Top Position. All Rights Reserved. 
 * License: GNU/GPL 2, http://www.gnu.org/licenses/gpl-2.0.html
 */

defined('_JEXEC') or die('Restricted access'); 

jimport('joomla.application.component.helper');

class EasySourceHelper1
{
	function xxxx(xxxx)
	{	return $xxxxx;
	}
}


?>