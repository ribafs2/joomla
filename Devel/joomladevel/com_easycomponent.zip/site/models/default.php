<?php

/**
 * Easy Family System - Easy Source
 * Component Version 1.0.0 - Joomla! Version 1.7
 * Author: Top Position
 * info@aixeena.org
 * http://aixeena.org
 * Copyright (c) 2011 Top Position. All Rights Reserved. 
 * License: GNU/GPL 2, http://www.gnu.org/licenses/gpl-2.0.html
 */

defined('_JEXEC') or die('Restricted access'); 



class EasySourceModelDefault extends JModelLegacy
{
	
	var $_id = null;
	
	function __construct()
	{
		parent::__construct();
	}

}
?>
