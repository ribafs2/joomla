# Security Policy

## Reporting a Vulnerability

Report all security issues on the JCB website, and not on GitHub.

### [joomlacomponentbuilder.com/report-security-issues](http://joomlacomponentbuilder.com/report-security-issues)
