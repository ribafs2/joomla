### Steps to reproduce the issue


### Expected result


### Actual result


### System information (as much as possible)
- OS Name & Version: 
- MySql Version: 
- Apache Version: 
- PHP Version: 
- Joomla Version: 
- JCB Version: 
- Browser: 

### Additional comments

